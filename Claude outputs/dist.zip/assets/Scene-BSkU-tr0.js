import{r as e}from"./rolldown-runtime-hePW80VL.js";import{C as t,D as n,E as r,F as i,I as a,L as o,M as s,N as c,O as l,P as u,S as d,V as f,_ as p,a as m,b as h,c as g,d as _,f as v,h as y,i as b,j as x,k as S,l as C,m as w,n as T,o as E,p as D,r as O,s as k,t as A,u as j,v as ee,w as M,x as N,y as P,z as te}from"./three-DNVWkSm3.js";import{At as ne,B as F,D as I,E as re,G as ie,H as ae,K as oe,O as se,Ot as ce,Q as le,T as ue,U as de,V as fe,W as pe,a as me,b as he,c as ge,d as _e,f as ve,ft as ye,g as be,h as xe,i as Se,it as Ce,jt as we,k as Te,kt as Ee,l as De,m as Oe,nt as L,o as ke,p as Ae,s as je,t as Me,u as Ne,v as Pe,w as Fe,x as Ie,y as Le}from"./index-BM-D3axz.js";import{c as Re,i as ze,n as Be,o as Ve,r as He,s as Ue,t as We}from"./Backdrop-BIsOJU4P.js";var R=e(f(),1);function Ge(e){return e==null||!Number.isFinite(e)?0:Math.max(-15,Math.min(15,e))/15*40}function Ke(e,t){return e.priceChange?.[t]??null}function qe(e,t){return e.pos[1]+Ge(Ke(e,t))}var Je=.25,Ye=.8,Xe=.4,z={version:0,animating:!1,t:0};function Ze(){if(!z.animating)return{fade:1,reveal:1};let e=z.t;if(e<.25)return{fade:1-e/Je,reveal:1};let t=e-Je;return t<.8?{fade:0,reveal:0}:{fade:1,reveal:Math.min(1,(t-Ye)/Xe)}}var Qe=new WeakMap;function $e(e){let t=Qe.get(e);if(!t){let n=e.nodes.length,r=new Float32Array(n*3),i=new Float32Array(n).fill(1);e.nodes.forEach((e,t)=>{r[t*3]=e.pos[0],r[t*3+1]=e.pos[1],r[t*3+2]=e.pos[2]}),t={model:e,pos:r,scale:i},Qe.set(e,t)}return t}var B={id:null,version:0,dirty:new Set,blockClick:!1},V={plan:null,fade:1,reveal:1,landedAt:0},et=Math.PI*2,tt=.5,nt=.12,rt=.3,it=2.6,at=.5,ot=.5,st=1.12,ct=e=>{let t=e-1;return 1+2.12*t*t*t+st*t*t},lt=e=>e*e*(3-2*e);function ut(e){let t=(e+Math.PI)%et;return t<0&&(t+=et),t-Math.PI}function dt(e,t,n,r,i=1){let a=t.nodes.length,o=new Float32Array(a),s=new Float32Array(a),c=new Float32Array(a),l=new Float32Array(a),u=new Float32Array(a),d=new Float32Array(a),f=new Float32Array(a),p=new Float32Array(a),m=new Float32Array(a),h=new Uint8Array(a),g=.001;t.nodes.forEach(e=>{g=Math.max(g,e.size)}),t.nodes.forEach((i,a)=>{let _=e.nodeById.get(i.id),v,y,b;_?(v=_.pos[0]-n[0]+r[0],y=_.pos[1]-n[1]+r[1],b=_.pos[2]-n[2]+r[2],m[a]=i.size>.001?_.size/i.size:1):(h[a]=1,v=i.pos[0]*it,y=i.pos[1]*it,b=i.pos[2]*it,m[a]=1),o[a]=Math.hypot(v,b),c[a]=y,l[a]=Math.hypot(i.pos[0],i.pos[2]),d[a]=i.pos[1],u[a]=Math.atan2(i.pos[2],i.pos[0]),s[a]=o[a]<.001?u[a]:Math.atan2(b,v),f[a]=ut(u[a]-s[a]),p[a]=Math.min(tt,t.kind===`system`?nt*i.depth:rt*(1-i.size/g))});let _=[];return e.nodes.forEach(e=>{if(t.nodeById.has(e.id))return;let i=[e.pos[0]-n[0]+r[0],e.pos[1]-n[1]+r[1],e.pos[2]-n[2]+r[2]],a=Math.hypot(i[0],i[1],i[2]);_.push({pos:i,dir:a<.001?[0,1,0]:[i[0]/a,i[1]/a,i[2]/a],color:e.color,radius:e.size*3})}),{src:e,dst:t,t:0,n:a,dur:i,rA:o,thA:s,yA:c,rB:l,thB:u,yB:d,dth:f,delay:p,sizeRatio:m,spawn:h,ghosts:_}}function ft(e,t,n){let{pos:r,scale:i}=n,a=Math.min(e.n,i.length);for(let n=0;n<a;n+=1){let a=e.delay[n],o=Math.min(1,Math.max(0,(t-a)/(1-a)));if(o>=1){let t=e.dst.nodes[n].pos;r[n*3]=t[0],r[n*3+1]=t[1],r[n*3+2]=t[2],i[n]=1;continue}let s=ct(o),c=e.rA[n]+(e.rB[n]-e.rA[n])*s,l=e.dth[n]<0?-.5:ot,u=e.thA[n]+e.dth[n]*s+l*Math.sin(Math.PI*s);r[n*3]=Math.cos(u)*c,r[n*3+1]=e.yA[n]+(e.yB[n]-e.yA[n])*lt(o),r[n*3+2]=Math.sin(u)*c,i[n]=e.spawn[n]?lt(Math.min(1,o/at)):e.sizeRatio[n]+(1-e.sizeRatio[n])*s}}var H={version:0,animating:!1,t:0,applied:NaN},pt=.15,mt=.6,ht=.3;function gt(){if(!H.animating)return{fade:1,reveal:1};let e=H.t;if(e<.15)return{fade:1-e/pt,reveal:1};let t=e-pt;return t<.6?{fade:0,reveal:0}:{fade:1,reveal:Math.min(1,(t-mt)/ht)}}function _t(){let e=L.getState();return e.phase===`system`?1:Ae(e.spread)}var vt=.01,yt=e=>e<.5?2*e*e:1-(-2*e+2)**2/2;function bt(e){B.dirty.clear(),e.nodes.forEach(e=>B.dirty.add(e.id)),B.version+=1}function xt({model:e}){let t=(0,R.useMemo)(()=>{let t=new Map;return e.nodes.forEach((e,n)=>t.set(e.id,n)),t},[e]),n=(0,R.useRef)({model:null,applied:``,from:new Float32Array,to:new Float32Array,skip:new Set,lastVersion:B.version,rebuilt:!1}).current;return(0,R.useEffect)(()=>()=>{z.animating=!1,z.t=0},[]),C((r,i)=>{let a=Math.min(i,.05),o=L.getState(),s=$e(e);if(n.model!==e&&(n.model=e,n.applied=``,n.from=new Float32Array(e.nodes.length),n.to=new Float32Array(e.nodes.length),n.skip.clear(),n.rebuilt=!1,z.animating=!1,z.t=0),V.plan){n.lastVersion=B.version;return}if(H.animating||o.spread>0||H.applied>0){n.lastVersion=B.version;return}let c=e.nodes.length,l=o.altitudeOn?`on:${o.altitudeWindow}`:`off`,u=t=>o.altitudeOn?qe(e.nodes[t],o.altitudeWindow):e.nodes[t].pos[1],d=B.id!==null||B.version!==n.lastVersion||V.plan!==null;if(n.lastVersion=B.version,!z.animating&&l!==n.applied){if(!n.applied){let t=!1;for(let e=0;e<c;e+=1){let n=u(e);Math.abs(n-s.pos[e*3+1])>vt&&(t=!0),s.pos[e*3+1]=n}n.applied=l,t&&bt(e)}else if(!d){let e=!1;for(let t=0;t<c;t+=1)n.from[t]=s.pos[t*3+1],n.to[t]=u(t),Math.abs(n.to[t]-n.from[t])>vt&&(e=!0);n.applied=l,e&&(n.skip.clear(),n.rebuilt=!1,z.animating=!0,z.t=0,z.version+=1)}}if(!z.animating)return;if(z.t+=a,B.id){let e=t.get(B.id);e!==void 0&&n.skip.add(e)}let f=z.t-Je;if(f>0){let e=yt(Math.min(1,f/Ye));for(let t=0;t<c;t+=1)n.skip.has(t)||(s.pos[t*3+1]=n.from[t]+(n.to[t]-n.from[t])*e)}!n.rebuilt&&f>=.8&&(n.rebuilt=!0,bt(e)),z.t>=1.4500000000000002&&(z.animating=!1,z.t=0)}),null}function St(...e){for(let t of e)t.needsUpdate=!0}var Ct={anim:!1},wt=1.35,Tt=.35,Et=`#141a3a`,Dt=.68,Ot=`
  attribute vec3 aColor;
  attribute vec2 aCell;
  attribute vec4 aName;
  attribute float aAspect;
  attribute vec4 aState;
  attribute vec4 aRole;
  attribute vec3 aRoleColor;
  varying vec2 vQ;
  varying float vAspect;
  varying vec3 vColor;
  varying vec2 vCell;
  varying vec4 vName;
  varying float vAlpha;
  varying float vEmph;
  varying float vBright;
  varying float vNameOn;
  varying vec4 vRole;
  varying vec3 vRoleColor;
  void main() {
    vQ = vec2(uv.x * aAspect, uv.y * ${wt.toFixed(2)} - ${Tt.toFixed(2)});
    vAspect = aAspect; vColor = aColor; vCell = aCell; vName = aName;
    vAlpha = aState.x; vEmph = aState.y; vBright = aState.z; vNameOn = aState.w;
    vRole = aRole; vRoleColor = aRoleColor;
    gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(position, 1.0);
  }
`,kt=`
  uniform sampler2D uAtlas;   // 로고 아틀라스
  uniform float uCell;        // 로고 셀 크기 (uv 단위)
  uniform sampler2D uNames;   // 이름 아틀라스
  uniform vec3 uPill;
  varying vec2 vQ;
  varying float vAspect;
  varying vec3 vColor;
  varying vec2 vCell;
  varying vec4 vName;
  varying float vAlpha;
  varying float vEmph;
  varying float vBright;
  varying float vNameOn;
  varying vec4 vRole;
  varying vec3 vRoleColor;

  void main() {
    if (vAlpha < 0.01) discard;
    // 픽셀 하나의 크기 (칩 높이 단위) — 안티에일리어싱 폭
    float aa = max(fwidth(vQ.y), 1e-4) * 1.2;
    float dim = vBright * mix(0.4, 1.0, vEmph);

    // (a) 스템 — 아래로 갈수록 옅어져 행성에 묻힌다
    if (vQ.y < 0.0) {
      float stem = 1.0 - smoothstep(0.03 - aa, 0.03 + aa, abs(vQ.x - 0.5));
      stem *= smoothstep(-0.35, -0.22, vQ.y);
      if (stem < 0.004) discard;
      gl_FragColor = vec4(vColor * dim, stem * 0.7 * vAlpha);
      return;
    }

    // (b) 캡슐 마스크
    float d = length(vQ - vec2(clamp(vQ.x, 0.5, vAspect - 0.5), 0.5)) - 0.5;
    float mask = 1.0 - smoothstep(-aa, aa, d);
    if (mask < 0.004) discard;
    vec3 col = uPill;
    float alpha = 0.9;

    // (c) 로고 원 — 흰 바탕 로고 + 산업색 림. 아틀라스는 캔버스 좌표(y 아래)라 v 를 뒤집어 읽는다
    float lr = length(vQ - vec2(0.5, 0.5));
    if (lr < 0.42 + aa) {
      vec2 luv = (vQ - 0.08) / 0.84;
      vec3 logo = texture2D(uAtlas, vCell + vec2(luv.x, 1.0 - luv.y) * uCell).rgb;
      logo = mix(logo, vColor, smoothstep(0.36 - aa, 0.36 + aa, lr));
      float inside = 1.0 - smoothstep(0.42 - aa, 0.42 + aa, lr);
      col = mix(col, logo, inside);
      alpha = mix(alpha, 1.0, inside);
    }

    // (d) 역할 태그 — 유형색 작은 캡슐 + 어두운 글자 (aRole.w > 0 일 때만)
    float roleW = vRole.w > 0.0 ? (vRole.z / vRole.w) * 0.8 : 0.0;
    if (roleW > 0.0) {
      float x0 = 1.0;
      float rd = length(vQ - vec2(clamp(vQ.x, x0 + 0.38, x0 + roleW - 0.38), 0.5)) - 0.38;
      float tag = 1.0 - smoothstep(-aa, aa, rd);
      if (tag > 0.001) {
        float ru = clamp((vQ.x - x0) / roleW, 0.0, 1.0);
        float ry = (vQ.y - 0.1) / 0.8;
        vec4 g = texture2D(uNames, vec2(vRole.x + ru * vRole.z, vRole.y + (1.0 - clamp(ry, 0.0, 1.0)) * vRole.w));
        // 글자는 흰색으로 구워져 있으니 r*a 가 글자 알파 (그림자는 제외)
        float glyph = g.r * g.a * step(0.0, ry) * step(ry, 1.0);
        col = mix(col, mix(vRoleColor, vec3(0.06, 0.08, 0.16), glyph), tag);
      }
    }

    // (e) 기업명 — 언제나 눌리지 않은 제 비율(nameFull)로 그린다. 남은 폭(nameW)에 맞춰 넣으면 캡슐 폭이
    // 이름 폭과 어긋난 프레임에서 글자가 가로로 찌그러진다. 폭이 모자라면 눌러 넣는 대신 그만큼만 드러낸다
    float nameX = 1.0 + roleW + (roleW > 0.0 ? 0.15 : 0.0);
    float nameW = vAspect - 0.3 - nameX;
    float nameFull = (vName.z / max(vName.w, 1e-6)) * ${Dt.toFixed(2)};
    if (vName.w > 0.0 && vNameOn > 0.01 && nameW > 0.02 && nameFull > 0.0 && vQ.x >= nameX && vQ.x <= nameX + nameW) {
      float nu = (vQ.x - nameX) / nameFull;
      float ny = (vQ.y - ${(.31999999999999995/2).toFixed(2)}) / ${Dt.toFixed(2)};
      if (nu <= 1.0 && ny >= 0.0 && ny <= 1.0) {
        vec4 tx = texture2D(uNames, vec2(vName.x + nu * vName.z, vName.y + (1.0 - ny) * vName.w));
        col = mix(col, tx.rgb, tx.a * vNameOn);
      }
    }

    col *= dim;
    gl_FragColor = vec4(col, mask * alpha * vAlpha);
  }
`;function At(e,t){if(!(e>0))return!1;let n=t.x*e,r=t.y*wt-Tt;if(r<0)return!1;let i=Math.min(Math.max(n,.5),e-.5);return Math.hypot(n-i,r-.5)<=.5}var U=128,jt=16,Mt=2048,Nt=`Pretendard Variable, Pretendard, "Malgun Gothic", "Apple SD Gothic Neo", "Segoe UI", sans-serif`,Pt=250,Ft=null,W=null,G=null,It=new Map,Lt=new Set,Rt=0,zt=null,Bt=null,Vt=null,Ht=null,Ut=new a,Wt=1/jt;function Gt(){return G||(Ft=document.createElement(`canvas`),Ft.width=Ft.height=Mt,W=Ft.getContext(`2d`),G=new D(Ft),G.flipY=!1,G.colorSpace=s,G.minFilter=N,G.magFilter=N,G.generateMipmaps=!1,G.anisotropy=4,G)}function Kt(e){zt=e}var qt=24,Jt=[],Yt=0;function Xt(){Yt=0,W&&(Jt.splice(0,qt).forEach(({index:e,img:t})=>{let{x:n,y:r}=an(e);W.fillStyle=rn(t)??`#ffffff`,W.fillRect(n,r,U,U);let i=U*.9,a=Math.min(i/t.width,i/t.height),o=t.width*a,s=t.height*a;W.drawImage(t,n+(U-o)/2,r+(U-s)/2,o,s),W.restore(),`close`in t&&t.close(),Qt(e)}),Jt.length&&(Yt=requestAnimationFrame(Xt)))}function Zt(e,t){Jt.push({index:e,img:t}),Yt||=requestAnimationFrame(Xt)}function Qt(e){Lt.add(e),!Rt&&(Rt=window.setTimeout($t,Pt))}function $t(){if(Rt=0,!G||!Ft||Lt.size===0)return;let e=zt?!!zt.properties.get(G).__webglTexture:!1;if(!zt||!e||G.version===0){Lt.clear(),G.needsUpdate=!0;return}try{(!Bt||!Vt||!Ht)&&(Bt=document.createElement(`canvas`),Bt.width=Bt.height=U,Vt=Bt.getContext(`2d`),Ht=new D(Bt),Ht.flipY=!1,Ht.colorSpace=s),Lt.forEach(e=>{let{x:t,y:n}=en(e);Vt.clearRect(0,0,U,U),Vt.drawImage(Ft,t,n,U,U,0,0,U,U),zt.copyTextureToTexture(Ht,G,null,Ut.set(t,n))}),Lt.clear()}catch{Lt.clear(),G.needsUpdate=!0}}function en(e){return{x:e%jt*U,y:Math.floor(e/jt)*U}}var tn=null;function nn(){if(tn)return tn;let e=document.createElement(`canvas`);return e.width=e.height=16,tn=e.getContext(`2d`,{willReadFrequently:!0}),tn}function rn(e){let t=nn();t.clearRect(0,0,16,16),t.drawImage(e,0,0,16,16);let n=t.getImageData(0,0,16,16).data,r=0,i=0,a=0,o=0,s=0,c=[];for(let e=0;e<16;e+=1)c.push(e,240+e,e*16,e*16+15);return c.forEach(e=>{let t=e*4;n[t+3]<40?s+=1:(r+=n[t],i+=n[t+1],a+=n[t+2],o+=1)}),s>c.length*.5||o===0?null:`rgb(${Math.round(r/o)},${Math.round(i/o)},${Math.round(a/o)})`}function an(e){let{x:t,y:n}=en(e);return W.save(),W.clearRect(t,n,U,U),W.beginPath(),W.arc(t+U/2,n+U/2,U/2-1,0,Math.PI*2),W.clip(),{x:t,y:n}}async function on(e){if(typeof createImageBitmap==`function`)try{let t=await fetch(e);return t.ok?await createImageBitmap(await t.blob()):null}catch{}return new Promise(t=>{let n=new Image;n.onload=()=>t(n),n.onerror=()=>t(null),n.src=e})}function sn(e,t,n,r){Gt();let i=It.get(e);if(i!==void 0)return i;let a=It.size;if(a>=256)return-1;It.set(e,a);{let{x:e,y:r}=an(a),i=W.createRadialGradient(e+U*.4,r+U*.36,U*.08,e+U/2,r+U/2,U*.55);i.addColorStop(0,`#f6f7fb`),i.addColorStop(1,`#d9dde8`),W.fillStyle=i,W.fillRect(e,r,U,U),W.fillStyle=n,W.textAlign=`center`,W.textBaseline=`middle`,W.font=`800 ${t.length>1?50:62}px ${Nt}`,W.fillText(t,e+U/2,r+U/2+3),W.restore(),G.needsUpdate=!0}return r&&on(r).then(e=>{e&&Zt(a,e)}),a}function cn(e){return e<0?[0,0]:[e%jt*Wt,Math.floor(e/jt)*Wt]}var ln=`
  attribute vec3 aColor;
  attribute float aBright;
  attribute float aEmph;
  attribute float aAlpha;
  attribute vec2 aCell;
  varying vec3 vColor;
  varying vec2 vUv;
  varying float vBright;
  varying float vEmph;
  varying float vAlpha;
  varying vec2 vCell;
  void main() {
    vColor = aColor; vUv = uv; vBright = aBright; vEmph = aEmph; vAlpha = aAlpha; vCell = aCell;
    gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(position, 1.0);
  }
`,un=`
  uniform sampler2D uAtlas;
  uniform float uCell;      // 아틀라스 셀 크기 (uv 단위)
  varying vec3 vColor;
  varying vec2 vUv;
  varying float vBright;
  varying float vEmph;
  varying float vAlpha;
  varying vec2 vCell;
  void main() {
    if (vAlpha < 0.01) discard;
    vec2 p = vUv * 2.0 - 1.0;
    float r = length(p);
    float aa = fwidth(r) * 1.2;
    float mask = 1.0 - smoothstep(1.0 - aa, 1.0, r);
    if (mask < 0.004) discard;
    // 아틀라스는 캔버스 좌표(y 아래)라 v 를 뒤집어 읽는다
    vec2 uv = vec2(vUv.x, 1.0 - vUv.y);
    vec3 col = texture2D(uAtlas, vCell + uv * uCell).rgb;
    // 산업색 테두리: 반지름의 9%, 최소 1px 정도 폭
    float rimW = max(0.09, fwidth(r) * 1.6);
    float rim = smoothstep(1.0 - rimW - aa, 1.0 - rimW, r);
    col = mix(col, vColor, rim);
    col *= vBright;
    col *= mix(0.35, 1.0, vEmph);
    gl_FragColor = vec4(col, mask * vAlpha);
  }
`,dn=2048,fn=44,pn=`400 36px ${Nt}`,mn=null,hn=null,K=null,gn=new Map,_n=[],vn=0,yn=0,bn=!1;function xn(){return K||(mn=document.createElement(`canvas`),mn.width=mn.height=dn,hn=mn.getContext(`2d`),K=new D(mn),K.flipY=!1,K.colorSpace=s,K.minFilter=d,K.magFilter=N,K.generateMipmaps=!0,K.anisotropy=4,Sn(),K)}function Sn(){bn||typeof document>`u`||!(`fonts`in document)||(bn=!0,document.fonts.ready.then(()=>{hn&&K&&(_n.forEach(Cn),K.needsUpdate=!0)}))}function Cn(e){let t=hn;t.save(),t.clearRect(e.x,e.y,e.w,fn),t.beginPath(),t.rect(e.x,e.y,e.w,fn),t.clip(),t.font=pn,t.textAlign=`center`,t.textBaseline=`middle`;let n=e.w-24,r=t.measureText(e.text).width,i=r>n?n/r:1;t.translate(e.x+e.w/2,e.y+fn/2+1),t.scale(i,1),t.shadowColor=`rgba(3,6,14,0.9)`,t.shadowBlur=4,t.fillStyle=`rgba(3,6,14,0.85)`,t.fillText(e.text,0,0),t.shadowBlur=0,t.fillStyle=`#ffffff`,t.fillText(e.text,0,0),t.restore()}function wn(e){xn();let t=gn.get(e);if(t!==void 0)return t;let n=e.trim()||`·`;hn.font=pn;let r=Math.min(dn,Math.ceil(hn.measureText(n).width)+24);if(vn+r>dn&&(vn=0,yn+=fn),yn+fn>dn)return gn.set(e,null),null;let i={text:n,x:vn,y:yn,w:r};vn+=r,_n.push(i),Cn(i),K.needsUpdate=!0;let a={u:i.x/dn,v:i.y/dn,w:r/dn,h:fn/dn,aspect:r/fn};return gn.set(e,a),a}var Tn=new Map;function En(e){let t=Tn.get(e);return t||(t={scale:.001,bright:1,tagA:0,chipA:0,nameOn:1},Tn.set(e,t)),t}var q=te(),J=new r,Dn=new o,On=new o,kn=new o,An=new o,jn=new o,Mn=new n,Nn=new o,Pn=new o,Fn=new o,In=new o,Ln=new a,Rn=new x,zn=6,Y={id:null,index:-1,x:0,y:0,active:!1,cursor:``,live:null,touchLike:!1},Bn=.6,Vn=22,Hn=.72,X={live:null,index:-1,active:!1,target:new o,vel:new o,origin:new o},Un=new WeakMap;function Wn(e,t,n,r,i,a){Y.id=e,Y.touchLike=a,Y.index=t,Y.x=n,Y.y=r,Y.active=!1,Y.live=i,B.id=e,B.blockClick=!1}var Z={id:null,timer:null,fired:!1,live:null},Gn=350,Kn={id:null,t:0};function qn(){Z.timer!==null&&clearTimeout(Z.timer),Z.timer=null,Z.id!==null&&(Z.id=null,Z.live=null,L.getState().setHold(null))}function Jn(e,t,n,r,i){qn(),Z.id=e,Z.fired=!1,Z.live=r,L.getState().setHold({id:e,x:t,y:n}),Z.timer=setTimeout(()=>{Z.timer=null,Z.id===e&&(Z.id=null,Z.live=null,Z.fired=!0,L.getState().setHold(null),Y.id=null,Y.live=null,B.id=null,navigator.vibrate?.(12),i())},550)}function Yn(e){if(!Y.touchLike)return Kn.id=null,!1;let t=performance.now(),n=Kn.id===e&&t-Kn.t<Gn;return Kn.id=n?null:e,Kn.t=t,n}var Xn=[],Zn=[];function Qn(e,t,n,r){e.sort((e,t)=>n[t]-n[e]),Zn.length=0;for(let n of e){let e=n*4,i=t[e]-er,a=t[e+1]-er,o=t[e+2]+er,s=t[e+3]+er,c=!1;for(let e of Zn){let n=e*4;if(i<t[n+2]&&t[n]<o&&a<t[n+3]&&t[n+1]<s){c=!0;break}}c?r[n]=0:Zn.push(n)}}var $n={galaxy:[520,150,115],system:[900,620,460]},er=4,tr=40,nr=1.3,rr=10,ir=.9,ar=1,or=.05;function sr(e){let t=[];return function(n,r){t.length=0,h.prototype.raycast.call(this,n,t);for(let n of t)n.instanceId!==void 0&&n.uv&&e(n.instanceId,n.uv)&&r.push(n)}}function cr({model:e,emphasis:n,hoveredId:r,onHover:i,onClick:a,showLabels:s=!0,onDoubleClick:u,roleTags:d=null}){let f=ye(),m=(0,R.useRef)(null),h=(0,R.useRef)(null),g=(0,R.useRef)(null),y=(0,R.useRef)([]),b=(0,R.useRef)([]),x=e.nodes.length,S=$e(e),T=j(e=>e.gl),E=j(e=>e.camera),D=(0,R.useMemo)(()=>e.nodes.map(e=>{let t=ue(e.id)%1e3/1e3,n=e.size*3,r=Ue(e.color),i=.5+t*9;return{node:e,radius:n,palette:r,variant:`land`,seed:i,geo:Ve(n,r,i,2,.45)}}),[e]);(0,R.useEffect)(()=>()=>{D.forEach(e=>{e.geo.dispose()})},[D]),(0,R.useEffect)(()=>{V.plan||e.nodes.forEach(e=>{En(e.id).scale=.001})},[e]);let O=(0,R.useMemo)(()=>{let t=new Float32Array(x*3),n=new Float32Array(x).fill(1),r=new Float32Array(x).fill(1),i=new Float32Array(x),a=new Float32Array(x*2),s=new Float32Array(x),u=new Float32Array(x).fill(1),d=[],f=new Float32Array(x*4),m=new w,h=new o;de.forEach(e=>wn(ae[e].label)),e.nodes.forEach((e,n)=>{m.set(e.color),t[n*3]=m.r,t[n*3+1]=m.g,t[n*3+2]=m.b,s[n]=e.size,h.x+=e.pos[0],h.y+=e.pos[1],h.z+=e.pos[2];let[r,i]=cn(sn(`${e.market}|${e.stockCode}|${e.name}`,le(e.name),e.color,we(e.stockCode,e.market)));a[n*2]=r,a[n*2+1]=i;let o=wn(e.name);d.push(o),o&&(f[n*4]=o.u,f[n*4+1]=o.v,f[n*4+2]=o.w,f[n*4+3]=o.h)}),x>0&&h.multiplyScalar(1/x);let g=0;e.nodes.forEach(e=>{g=Math.max(g,Dn.fromArray(e.pos).distanceTo(h)+e.size*4)});let y=new c(h,g+40),b=(e,t)=>{let n=new P(e,t);return n.setUsage(p),n},S=new l(2,2);S.setAttribute(`aColor`,new P(t,3)),S.setAttribute(`aCell`,new P(a,2));let C=b(n,1),T=b(r,1),E=b(i,1);S.setAttribute(`aBright`,C),S.setAttribute(`aEmph`,T),S.setAttribute(`aAlpha`,E);let D=new l(1,wt);D.translate(0,wt/2-Tt,0),D.setAttribute(`aColor`,new P(t,3)),D.setAttribute(`aCell`,new P(a,2)),D.setAttribute(`aName`,new P(f,4));let O=new Float32Array(x).fill(1),k=b(O,1),A=new Float32Array(x*4);for(let e=0;e<x;e+=1)A[e*4+1]=1,A[e*4+2]=1,A[e*4+3]=1;let j=b(A,4),ee=b(new Float32Array(x*4),4),M=b(new Float32Array(x*3),3);D.setAttribute(`aAspect`,k),D.setAttribute(`aState`,j),D.setAttribute(`aRole`,ee),D.setAttribute(`aRoleColor`,M);let N=new v,te=new _($e(e).pos,3);te.setUsage(p),N.setAttribute(`position`,te),N.setAttribute(`color`,new _(t.slice(),3));let ne=new _(s,1);ne.setUsage(p);let F=new _(u,1);return F.setUsage(p),N.setAttribute(`aSize`,ne),N.setAttribute(`aAlpha`,F),{geo:S,brightAttr:C,emphAttr:T,alphaAttr:E,chipGeo:D,chipAspect:k,chipState:j,chipRole:ee,chipRoleColor:M,aspectArr:O,nameCells:d,bounds:y,haloGeo:N,haloPos:te,haloSize:ne,haloAlpha:F}},[e,x]);(0,R.useEffect)(()=>()=>{O.geo.dispose(),O.chipGeo.dispose(),O.haloGeo.dispose()},[O]),(0,R.useEffect)(()=>{let t=O.chipRole.array,n=O.chipRoleColor.array;if(t.fill(0),d){let r=new w;e.nodes.forEach((e,i)=>{let a=d.get(e.id);if(!a)return;let o=wn(ae[a].label);o&&(t[i*4]=o.u,t[i*4+1]=o.v,t[i*4+2]=o.w,t[i*4+3]=o.h,r.set(ie(a)),n[i*3]=r.r,n[i*3+1]=r.g,n[i*3+2]=r.b)})}St(O.chipRole,O.chipRoleColor)},[d,e,O]);let k=(0,R.useMemo)(()=>({h:new Float32Array(x),target:new Float32Array(x),rect:new Float32Array(x*4),prio:new Float32Array(x)}),[x]);(0,R.useEffect)(()=>{let e=(e,t)=>{if(e){Object.assign(e.userData,t),e.boundingSphere=O.bounds.clone(),e.instanceMatrix.setUsage(p);for(let t=0;t<x;t+=1)J.position.set(0,0,0),J.quaternion.identity(),J.scale.setScalar(.001),J.updateMatrix(),e.setMatrixAt(t,J.matrix);e.instanceMatrix.needsUpdate=!0}};e(m.current,{pick:`node`}),e(h.current,{pick:`node`})},[e,x,O]);let A=(0,R.useMemo)(()=>({uAtlas:{value:Gt()},uCell:{value:Wt}}),[]),ee=(0,R.useMemo)(()=>({uAtlas:{value:Gt()},uCell:{value:Wt},uNames:{value:xn()},uPill:{value:new w(Et)}}),[]),M=(0,R.useMemo)(()=>({uMap:{value:Be()}}),[]),N=Re(3);C((i,a)=>{if(X.active&&X.live===S){let e=Math.min(a,.05),t=X.index*3,n=S.pos[t],r=S.pos[t+1],i=S.pos[t+2],o=2*Hn*Math.sqrt(Vn),s=X.vel;s.x+=((X.target.x-n)*Vn-s.x*o)*e,s.y+=((X.target.y-r)*Vn-s.y*o)*e,s.z+=((X.target.z-i)*Vn-s.z*o)*e,S.pos[t]=n+s.x*e,S.pos[t+1]=r+s.y*e,S.pos[t+2]=i+s.z*e,B.version+=1,!Y.active&&X.target.distanceToSquared(Dn.set(S.pos[t],S.pos[t+1],S.pos[t+2]))<1e-4&&s.lengthSq()<1e-4&&(S.pos[t]=X.target.x,S.pos[t+1]=X.target.y,S.pos[t+2]=X.target.z,X.active=!1,X.live=null)}let o=1-.001**a,c=1-1e-4**a,l=i.clock.elapsedTime,u=i.camera,d=m.current,f=h.current,p=V.plan!==null;kn.set(0,1,0).applyQuaternion(u.quaternion),An.set(1,0,0).applyQuaternion(u.quaternion);let _=u,v=_.isPerspectiveCamera?_.fov:52,C=Math.tan(t.degToRad(v)/2),w=2*C*tr/Math.max(1,i.size.height),T=i.size.width,E=i.size.height,A=$n[e.kind],j=Math.max(1,1/Math.max(.2,Math.min(1,T/Math.max(1,E)))),ee=t=>t.id===r?5:t.id===e.centerId?4:n.pinned.has(t.id)?3:2-t.tier;Xn.length=0;let M=O.chipRole.array;D.forEach((i,a)=>{let{node:f}=i,m=En(f.id),h=n.node.get(f.id)??1,g=f.id===r,_=f.id===e.centerId,v=n.pinned.has(f.id),x=(g?1.18:1)*(_?1.1:1)*(.7+.3*h),D=(g?1.15:_?1.06:1)*(.42+.58*h),N=m.scale+=(x-m.scale)*o,P=m.bright+=(D-m.bright)*o;Dn.fromArray(S.pos,a*3);let te=y.current[a];te&&(te.position.copy(Dn),te.scale.setScalar(N*S.scale[a]));let ne=b.current[a];ne&&(ne.rotation.y=l*.12+i.seed,ne.material.color.setScalar(P)),On.copy(u.position).sub(Dn);let F=On.length();On.multiplyScalar(1/Math.max(1e-6,F));let I=i.radius*N*S.scale[a],re=n.badges.has(f.id)&&(!p||_)?1:0,ie=m.tagA+=(re-m.tagA)*c;d&&(J.position.copy(Dn).addScaledVector(On,I*1.04),J.quaternion.copy(u.quaternion),J.scale.setScalar(ie<.01?.001:I*.62*(.6+.4*ie)),J.updateMatrix(),d.setMatrixAt(a,J.matrix),O.brightAttr.array[a]=g?1.05:1,O.emphAttr.array[a]=h,O.alphaAttr.array[a]=ie),O.haloSize.array[a]=I*3.2*(.5+.5*h),O.haloAlpha.array[a]=(.15+.85*h)*.22,m.nameOn=s&&(v||_)?1:0;let ae=M[a*4+3]>0?M[a*4+2]/M[a*4+3]*.8:0;O.aspectArr[a]=1+m.nameOn*((O.nameCells[a]?.aspect??0)*Dt+.3)+(ae>0?ae+.15:0),k.h[a]=Math.max(t.clamp(F*w,nr,rr),I*ir);let oe=A[Math.min(f.tier,A.length-1)]*j,se=v?1:1-t.smoothstep(F,oe*.75,oe);if(se*=.15+.85*h,p&&!_&&(se=0),se>.01){if(jn.copy(Dn).addScaledVector(On,I*.2).applyMatrix4(u.matrixWorldInverse),jn.z>=-.001)se=0;else{let e=E/(2*-jn.z*C);jn.applyMatrix4(u.projectionMatrix);let t=(jn.x+1)*.5*T,n=(1-jn.y)*.5*E,r=k.h[a],i=O.aspectArr[a],o=n-(I*1.05+Tt*r)*e,s=a*4;k.rect[s]=t-.5*r*e,k.rect[s+1]=o-r*e,k.rect[s+2]=t+(i-.5)*r*e,k.rect[s+3]=o,k.rect[s+2]<0||k.rect[s]>T||k.rect[s+3]<0||k.rect[s+1]>E?se=0:(k.prio[a]=ee(f)*10+f.size,Xn.push(a))}}k.target[a]=se}),Qn(Xn,k.rect,k.prio,k.target),d&&(d.instanceMatrix.needsUpdate=!0,O.brightAttr.needsUpdate=!0,O.emphAttr.needsUpdate=!0,O.alphaAttr.needsUpdate=!0),O.haloSize.needsUpdate=!0,O.haloAlpha.needsUpdate=!0;let N=Un.get(O);if(N||(N={version:B.version},Un.set(O,N)),(p||z.animating||H.animating||N.version!==B.version)&&(N.version=B.version,O.haloPos.needsUpdate=!0),f){let e=O.chipState.array;for(let t=0;t<x;t+=1){let i=D[t],{node:a}=i,o=En(a.id),s=o.chipA+=(k.target[t]-o.chipA)*c,l=O.aspectArr[t];if(e[t*4]=s,e[t*4+1]=n.node.get(a.id)??1,e[t*4+2]=a.id===r?1.1:1,e[t*4+3]=o.nameOn,s<.01)J.position.set(0,0,0),J.scale.setScalar(.001);else{let e=k.h[t];Dn.fromArray(S.pos,t*3),On.copy(u.position).sub(Dn).normalize();let n=i.radius*o.scale*S.scale[t];J.position.copy(Dn).addScaledVector(kn,n*1.05+Tt*e).addScaledVector(An,(l*.5-.5)*e).addScaledVector(On,n*.2),J.quaternion.copy(u.quaternion),J.scale.set(e*l,e,1)}J.updateMatrix(),f.setMatrixAt(t,J.matrix)}f.instanceMatrix.needsUpdate=!0,O.chipAspect.needsUpdate=!0,O.chipState.needsUpdate=!0}let P=g.current;if(P){let t=r?e.nodeById.get(r):void 0;if(t){let n=e.nodes.indexOf(t);P.visible=!0,P.position.fromArray(S.pos,n*3),P.scale.setScalar(D[n].radius*En(t.id).scale*S.scale[n]*3);let r=P.material;r.opacity=.35+Math.sin(l*3)*.08,r.color.set(t.color),r.rotation=l*.4}else P.visible=!1}});let te=(0,R.useMemo)(()=>sr((t,n)=>{let r=e.nodes[t];return!!r&&En(r.id).tagA>=or&&Math.hypot(n.x-.5,n.y-.5)<=.5}),[e]),ne=(0,R.useMemo)(()=>sr((t,n)=>{let r=e.nodes[t];return!!r&&En(r.id).chipA>=or&&At(O.aspectArr[t],n)}),[e,O]),F=e=>!V.plan&&!B.id&&(n.node.get(e)??1)>.05,I=t=>t.instanceId===void 0?null:e.nodes[t.instanceId]?.id??null,re=e=>{B.id||e&&e===r&&i(null)},oe=(e,t)=>{if(B.blockClick)return;let n=Yn(t);(e.nativeEvent.detail>=2||n)&&u?u(t):a(t)},se=(e,t)=>{if(!u)return;let n=e.nativeEvent;(n.pointerType===`touch`||f)&&Jn(t,n.clientX,n.clientY,S,()=>u(t))},ce=(e,t,n)=>{let r=L.getState();e.nativeEvent.button!==0||V.plan||r.phase===`warp`||Ct.anim||F(t)&&(e.stopPropagation(),Wn(t,n,e.nativeEvent.clientX,e.nativeEvent.clientY,S,e.nativeEvent.pointerType===`touch`||f),se(e,t))};return(0,R.useEffect)(()=>{let e=(e,t)=>{let n=T.domElement.getBoundingClientRect();return Ln.set((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),Rn.setFromCamera(Ln,E),Rn.ray.intersectPlane(Mn,Nn)},t=()=>{Y.active=!0,B.dirty.clear(),Y.id&&B.dirty.add(Y.id),Fn.fromArray(S.pos,Y.index*3),X.live=S,X.index=Y.index,X.active=!0,X.origin.copy(Fn),X.target.copy(Fn),X.vel.set(0,0,0),E.getWorldDirection(In),Mn.setFromNormalAndCoplanarPoint(In,Fn),e(Y.x,Y.y)?Pn.subVectors(Nn,Fn):Pn.set(0,0,0),Y.cursor=document.body.style.cursor,document.body.style.cursor=`grabbing`},n=n=>{if(Z.id&&Math.hypot(n.clientX-Y.x,n.clientY-Y.y)>=zn&&qn(),Y.id&&Y.live===S){if(!Y.active){if(Math.hypot(n.clientX-Y.x,n.clientY-Y.y)<zn)return;t()}e(n.clientX,n.clientY)&&(Nn.sub(Pn).sub(X.origin).multiplyScalar(Bn),X.target.copy(X.origin).add(Nn))}},r=()=>{qn(),Z.fired&&(Z.fired=!1,B.blockClick=!0,requestAnimationFrame(()=>{B.blockClick=!1})),Y.live===S&&(Y.active&&(document.body.style.cursor=Y.cursor,B.blockClick=!0,requestAnimationFrame(()=>{B.blockClick=!1}),i(null)),Y.id=null,Y.active=!1,Y.live=null,B.id=null)};return window.addEventListener(`pointermove`,n),window.addEventListener(`pointerup`,r),window.addEventListener(`pointercancel`,r),window.addEventListener(`blur`,r),()=>{window.removeEventListener(`pointermove`,n),window.removeEventListener(`pointerup`,r),window.removeEventListener(`pointercancel`,r),window.removeEventListener(`blur`,r),Z.live===S&&qn(),Y.live===S&&(Y.active&&(document.body.style.cursor=Y.cursor),Y.id=null,Y.active=!1,Y.live=null,B.id=null)}},[T,E,S,i]),(0,q.jsxs)(`group`,{children:[D.map((e,t)=>(0,q.jsxs)(`group`,{ref:e=>{y.current[t]=e},position:e.node.pos,scale:.001,children:[(0,q.jsx)(`mesh`,{ref:e=>{b.current[t]=e},geometry:e.geo,onUpdate:e=>{e.layers.enable(ar),e.userData.pick=`node`},onPointerOver:t=>{F(e.node.id)&&(t.stopPropagation(),i(e.node.id))},onPointerOut:()=>re(e.node.id),onPointerDown:n=>ce(n,e.node.id,t),onClick:t=>{F(e.node.id)&&(t.stopPropagation(),oe(t,e.node.id))},onDoubleClick:t=>{F(e.node.id)&&!B.blockClick&&(t.stopPropagation(),u?.(e.node.id))},children:(0,q.jsx)(`meshToonMaterial`,{vertexColors:!0,gradientMap:N})}),e.variant===`ring`&&(0,q.jsxs)(`mesh`,{rotation:[Math.PI/2-.42,.25,0],raycast:()=>null,onUpdate:e=>e.layers.enable(ar),children:[(0,q.jsx)(`ringGeometry`,{args:[e.radius*1.45,e.radius*2.05,40,1]}),(0,q.jsx)(`meshToonMaterial`,{color:e.palette.ring,gradientMap:N,side:2,transparent:!0,opacity:.9})]})]},e.node.id)),(0,q.jsx)(`instancedMesh`,{ref:m,args:[O.geo,void 0,x],frustumCulled:!1,renderOrder:3,raycast:te,onPointerMove:e=>{let t=I(e);t&&F(t)&&(e.stopPropagation(),i(t))},onPointerOut:e=>re(I(e)),onPointerDown:e=>{let t=I(e);t&&e.instanceId!==void 0&&ce(e,t,e.instanceId)},onClick:e=>{let t=I(e);t&&F(t)&&(e.stopPropagation(),oe(e,t))},onDoubleClick:e=>{let t=I(e);t&&F(t)&&!B.blockClick&&(e.stopPropagation(),u?.(t))},children:(0,q.jsx)(`shaderMaterial`,{vertexShader:ln,fragmentShader:un,uniforms:A,transparent:!0,depthWrite:!1,toneMapped:!1})}),(0,q.jsx)(`instancedMesh`,{ref:h,args:[O.chipGeo,void 0,x],frustumCulled:!1,renderOrder:4,raycast:ne,onPointerMove:e=>{let t=I(e);t&&F(t)&&(e.stopPropagation(),i(t))},onPointerOut:e=>re(I(e)),onPointerDown:e=>{let t=I(e);t&&e.instanceId!==void 0&&ce(e,t,e.instanceId)},onClick:e=>{let t=I(e);t&&F(t)&&(e.stopPropagation(),oe(e,t))},onDoubleClick:e=>{let t=I(e);t&&F(t)&&!B.blockClick&&(e.stopPropagation(),u?.(t))},children:(0,q.jsx)(`shaderMaterial`,{vertexShader:Ot,fragmentShader:kt,uniforms:ee,transparent:!0,depthWrite:!1,depthTest:!0,toneMapped:!1})}),(0,q.jsx)(`points`,{geometry:O.haloGeo,frustumCulled:!1,raycast:()=>null,renderOrder:1,children:(0,q.jsx)(`shaderMaterial`,{transparent:!0,depthWrite:!1,blending:2,vertexColors:!0,toneMapped:!1,uniforms:M,vertexShader:`
            attribute float aSize;
            attribute float aAlpha;
            varying vec3 vColor;
            varying float vAlpha;
            void main(){
              vColor = color; vAlpha = aAlpha;
              vec4 mv = modelViewMatrix * vec4(position, 1.0);
              gl_PointSize = aSize * (300.0 / -mv.z);
              gl_Position = projectionMatrix * mv;
            }
          `,fragmentShader:`
            uniform sampler2D uMap;
            varying vec3 vColor;
            varying float vAlpha;
            void main(){
              vec4 t = texture2D(uMap, gl_PointCoord);
              gl_FragColor = vec4(vColor * t.a, t.a * vAlpha);
            }
          `})}),(0,q.jsx)(`sprite`,{ref:g,visible:!1,raycast:()=>null,renderOrder:4,children:(0,q.jsx)(`spriteMaterial`,{map:He(),transparent:!0,depthWrite:!1,toneMapped:!1,blending:2})})]})}var lr=.16,ur={galaxy:0,system:.6},dr=8,Q=new o,fr=new o,pr=new o,mr=new o,hr=new o,gr=new o;function _r(e,t,n,r=0,i=0,a=0){Q.fromArray(e,r),fr.fromArray(t,i);let o=Q.distanceTo(fr);if(n.addVectors(Q,fr).multiplyScalar(.5),pr.copy(n),pr.lengthSq()<1e-6&&pr.set(0,1,0),pr.normalize().multiplyScalar(o*lr),pr.y+=o*lr*.35,n.add(pr),a<=0)return o;let s=Math.min(Math.hypot(Q.x,Q.z),Math.hypot(fr.x,fr.z))*a;if(s<=.001)return o;let c=1/0,l=.5,u=0,d=0;for(let a=1;a<dr;a+=1){let o=a/dr;vr(e,t,n,o,gr,r,i);let s=Math.hypot(gr.x,gr.z);s<c&&(c=s,l=o,u=gr.x,d=gr.z)}if(c>=s)return o;mr.set(-(fr.z-Q.z),0,fr.x-Q.x),mr.lengthSq()<1e-6&&mr.set(0,0,1),mr.normalize(),hr.set(n.x-(Q.x+fr.x)/2,0,n.z-(Q.z+fr.z)/2);let f=hr.dot(mr);Math.abs(f)<.001&&(f=(Q.x+fr.x)*mr.x+(Q.z+fr.z)*mr.z),f<0&&mr.negate();let p=u*mr.x+d*mr.z,m=-p+Math.sqrt(Math.max(0,p*p+s*s-c*c));return n.addScaledVector(mr,m/(2*l*(1-l))),o}function vr(e,t,n,r,i,a=0,o=0){let s=1-r;return i.set(0,0,0),i.addScaledVector(Q.fromArray(e,a),s*s),i.addScaledVector(n,2*s*r),i.addScaledVector(fr.fromArray(t,o),r*r),i}function yr(e){return .05+e*e*.22}var br=160,xr=.5,Sr=2.6,Cr=.36,wr=2.2,Tr=new o(0,1,0),Er=new o,Dr=new o,Or=new o,kr=new o,Ar=new r,jr=new w;function Mr({model:e,emphasis:n}){let r=(0,R.useRef)(null),i=(0,R.useMemo)(()=>new y(1,wr,8),[]);(0,R.useEffect)(()=>()=>i.dispose(),[i]);let a=$e(e),o=(0,R.useMemo)(()=>{let t=new Map;return e.nodes.forEach((e,n)=>t.set(e.id,n)),t},[e]),s=(0,R.useMemo)(()=>e.edges.filter(e=>e.directed&&(n.edge.get(e.id)??1)>=xr).sort((e,t)=>t.score-e.score).slice(0,br),[e,n]),c=(0,R.useCallback)(()=>{let i=r.current;if(!i)return;let c=0;s.forEach(r=>{let s=o.get(r.source),l=o.get(r.target);if(s===void 0||l===void 0)return;let u=c;c+=1;let d=n.edge.get(r.id)??1,f=r.score/100,p=Math.max(Cr,yr(f)*Sr),m=_r(a.pos,a.pos,Er,s*3,l*3,ur[e.kind]),h=(e.nodeById.get(r.target)?.size??1)*3*1.15+p*wr/2,g=t.clamp(1-h/Math.max(.001,m),.5,.93);vr(a.pos,a.pos,Er,g,Dr,s*3,l*3),vr(a.pos,a.pos,Er,Math.min(1,g+.03),Or,s*3,l*3),vr(a.pos,a.pos,Er,Math.max(0,g-.03),kr,s*3,l*3),kr.subVectors(Or,kr),kr.lengthSq()<1e-8&&kr.copy(Tr),kr.normalize(),Ar.position.copy(Dr),Ar.quaternion.setFromUnitVectors(Tr,kr),Ar.scale.setScalar(p),Ar.updateMatrix(),i.setMatrixAt(u,Ar.matrix),jr.set(fe(r.type)),jr.multiplyScalar(.35+.65*d),i.setColorAt(u,jr)}),i.count=c,i.instanceMatrix.needsUpdate=!0,i.instanceColor&&(i.instanceColor.needsUpdate=!0)},[s,e,n,a,o]);(0,R.useEffect)(()=>c(),[c]);let l=(0,R.useRef)({version:B.version,gated:!0}).current;return C(()=>{let e=r.current;if(!e)return;l.version!==B.version&&(l.version=B.version,c());let t=L.getState().phase===`warp`,n=Ze(),i=gt(),a=!t&&!V.plan&&V.reveal>=.99&&n.fade>=.99&&n.reveal>=.99&&i.fade>=.99&&i.reveal>=.99&&_t()>=.99;a&&l.gated&&c(),l.gated=!a,e.visible=a&&e.count>0}),(0,q.jsx)(`instancedMesh`,{ref:r,args:[i,void 0,br],frustumCulled:!1,renderOrder:3,raycast:()=>null,children:(0,q.jsx)(`meshBasicMaterial`,{color:`#ffffff`,toneMapped:!1,fog:!1})})}var Nr=90,Pr=6,Fr=.5,Ir=48,Lr=18,Rr=4,zr=.12,Br=new o,Vr=new o,Hr=new o,Ur=new o,Wr=new o,Gr=new o,Kr=new M;function qr(e,t){e.value=t}function Jr(e,t){let n=Ce[e],r=`${n?.label??String(e)} ${n?.directed?`▸`:`⇄`}`;return t?`${ne.mark} ${r}`:r}function Yr(){let e=L.getState();if(!e.showEdgeLabels||e.phase===`warp`||V.plan||V.reveal<.99)return!1;let t=Ze(),n=gt();return t.fade>=.99&&t.reveal>=.99&&n.fade>=.99&&n.reveal>=.99&&_t()>=.99}function Xr({model:e,emphasis:n,surprise:r,allEdges:i=!1}){let a=(0,R.useRef)(null),o=ur[e.kind],s=$e(e),c=(0,R.useMemo)(()=>{let t=new Map;return e.nodes.forEach((e,n)=>t.set(e.id,n)),t},[e]),u=(0,R.useMemo)(()=>{let e=new l(1,1),t=new P(new Float32Array(360),4),n=new P(new Float32Array(Nr),1),r=new P(new Float32Array(Nr),1);return t.setUsage(p),n.setUsage(p),r.setUsage(p),e.setAttribute(`aCell`,t),e.setAttribute(`aAspect`,n),e.setAttribute(`aAlpha`,r),{geo:e,cell:t,aspect:n,alpha:r}},[]);(0,R.useEffect)(()=>()=>u.geo.dispose(),[u]);let d=(0,R.useMemo)(()=>({uAtlas:{value:xn()},uWorldPerPx:{value:0}}),[]),f=(0,R.useRef)(0),m=(0,R.useRef)(!1),h=(0,R.useRef)([]);return C(l=>{let d=a.current;if(!d)return;if(f.current+=1,!Yr()){d.count=0;return}let p=l.camera,g=p.isPerspectiveCamera?p.fov:52,_=Math.tan(t.degToRad(g)/2),v=l.size.width,y=l.size.height;if(qr(d.material.uniforms.uWorldPerPx,2*_/Math.max(1,y)),Hr.set(0,1,0).applyQuaternion(p.quaternion),!m.current||f.current%Pr===0){m.current=!0;let t=[],a=L.getState().hoveredEdgeId;if((i?e.edges:a?[e.edgeById.get(a)].filter(e=>!!e):[]).forEach(e=>{let i=n.edge.get(e.id)??1,a=c.get(e.source),l=c.get(e.target);if(i<Fr||a===void 0||l===void 0)return;Ur.fromArray(s.pos,a*3).project(p),Wr.fromArray(s.pos,l*3).project(p);let u=(Ur.x+1)/2*v,d=(1-Ur.y)/2*y,f=(Wr.x+1)/2*v,m=(1-Wr.y)/2*y;if(Math.hypot(f-u,m-d)<Ir||(_r(s.pos,s.pos,Br,a*3,l*3,o),vr(s.pos,s.pos,Br,.5,Vr,a*3,l*3),Vr.addScaledVector(Hr,yr(e.score/100)*3+.6),Gr.copy(Vr).project(p),Gr.z>=1))return;let h=r.has(e.id),g=wn(Jr(e.type,h));if(!g)return;let _=g.aspect/(1-2*zr),b=(Gr.x+1)/2*v,x=(1-Gr.y)/2*y,S=Lr*_/2+Rr;t.push({edgeId:e.id,score:e.score,cell:g,aspect:_,rect:[b-S,x-13,b+S,x+13]})}),i&&t.length>1){t.sort((e,t)=>t.score-e.score);let e=[],n=(e,t)=>e[0]<t[2]&&e[2]>t[0]&&e[1]<t[3]&&e[3]>t[1];t.forEach(t=>{e.length>=Nr||e.some(e=>n(e.rect,t.rect))||e.push(t)}),h.current=e.map(e=>({edgeId:e.edgeId,cell:e.cell,aspect:e.aspect}))}else h.current=t.map(e=>({edgeId:e.edgeId,cell:e.cell,aspect:e.aspect}))}let b=u.cell.array,x=u.aspect.array,S=u.alpha.array,C=0;h.current.forEach(t=>{let r=e.edgeById.get(t.edgeId);if(!r)return;let i=c.get(r.source),a=c.get(r.target);if(i===void 0||a===void 0)return;_r(s.pos,s.pos,Br,i*3,a*3,o),vr(s.pos,s.pos,Br,.5,Vr,i*3,a*3),Vr.addScaledVector(Hr,yr(r.score/100)*3+.6),Kr.makeTranslation(Vr.x,Vr.y,Vr.z),d.setMatrixAt(C,Kr);let l=C*4;b[l]=t.cell.u,b[l+1]=t.cell.v,b[l+2]=t.cell.w,b[l+3]=t.cell.h,x[C]=t.aspect,S[C]=Math.min(1,n.edge.get(t.edgeId)??1),C+=1}),d.count=C,d.instanceMatrix.needsUpdate=!0,St(u.cell,u.aspect,u.alpha)}),(0,q.jsx)(`instancedMesh`,{ref:a,args:[u.geo,void 0,Nr],frustumCulled:!1,renderOrder:4,raycast:()=>null,children:(0,q.jsx)(`shaderMaterial`,{uniforms:d,vertexShader:Zr,fragmentShader:Qr,transparent:!0,depthWrite:!1,depthTest:!1,toneMapped:!1})})}var Zr=`
  attribute vec4 aCell;
  attribute float aAspect;
  attribute float aAlpha;
  uniform float uWorldPerPx;
  varying vec2 vUv;
  varying vec4 vCell;
  varying float vAspect;
  varying float vAlpha;
  void main() {
    vUv = uv;
    vCell = aCell;
    vAspect = aAspect;
    vAlpha = aAlpha;
    // 인스턴스 중심을 뷰 공간에서 구하고, 로컬 쿼드 오프셋은 투영 전에 뷰 공간 XY 에 직접 더한다 — 카메라를 그대로 따라가는 빌보드가 된다
    vec4 mv = modelViewMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
    float worldH = ${Lr.toFixed(1)} * uWorldPerPx * max(0.001, -mv.z);
    float worldW = worldH * aAspect;
    mv.xy += vec2(position.x * worldW, position.y * worldH);
    gl_Position = projectionMatrix * mv;
  }
`,Qr=`
  uniform sampler2D uAtlas;
  varying vec2 vUv;
  varying vec4 vCell;
  varying float vAspect;
  varying float vAlpha;
  void main() {
    if (vAlpha <= 0.003) discard;
    // 둥근 알약 마스크 — 세로 1, 가로 aspect 인 캡슐 (반지름 0.5)
    vec2 q = vec2((vUv.x - 0.5) * vAspect, vUv.y - 0.5);
    float halfW = max(0.0, vAspect * 0.5 - 0.5);
    float d = length(vec2(q.x - clamp(q.x, -halfW, halfW), q.y)) - 0.5;
    float aa = 0.035;
    float mask = 1.0 - smoothstep(-aa, aa, d);
    if (mask <= 0.004) discard;
    vec3 col = vec3(0.043, 0.063, 0.125); // rgba(11,16,32,.62) 의 rgb
    float alpha = 0.62 * mask;
    // 글자 — 가로 PAD 만큼 안쪽으로 넣고, 아틀라스는 캔버스 좌표(y 아래)라 v 를 뒤집어 읽는다.
    // r*a 로 그림자 헤일로를 걸러내(짙은 그림자는 r 이 거의 0) 순수 흰 글자만 마스크로 쓰고, 색은 무채색(#E6ECF5)으로 다시 칠한다 — 유형색을 쓰지 않는다
    float nu = (vUv.x - ${zr.toFixed(2)}) / ${(1-2*zr).toFixed(2)};
    if (nu >= 0.0 && nu <= 1.0) {
      vec4 tx = texture2D(uAtlas, vec2(vCell.x + nu * vCell.z, vCell.y + (1.0 - vUv.y) * vCell.w));
      float glyph = tx.r * tx.a;
      col = mix(col, vec3(0.902, 0.925, 0.961), glyph);
      alpha = max(alpha, glyph);
    }
    gl_FragColor = vec4(col, alpha * vAlpha);
  }
`,$r=null;function ei(){return $r===null&&($r=typeof navigator<`u`&&(navigator.hardwareConcurrency??8)<=4),$r}var ti=9e3,ni=4e3,ri=400/ti,ii=1400/ti,ai=110,oi=1.4,si=.4,ci=.8,li=.6,ui=.14,di=.05,fi=67.2,pi=140,mi=new w(`#dfe8ff`),hi=new w(`#9fb8ff`),gi=new w(`#ffd9a8`),_i=`#cfe0ff`,vi=new w;function yi({seed:e=0,radius:t=175,spiral:n=!0,warpRef:r}){let i=(0,R.useRef)(null),a=(0,R.useRef)(null),o=(0,R.useRef)(null),s=(0,R.useMemo)(()=>{let r=Math.max(28,t),i=ei()?ni:ti,a=Math.round(i*ri),o=Math.round(i*ii),s=i-a-o,c=re(e>>>0^2654435769),l=ai*r/175,u=()=>Math.max(-3,Math.min(3,Fe(c))),d=()=>{for(let e=0;e<24;e+=1){let e=r*Math.sqrt(c());if(c()<Math.exp(-e/l))return e}return r*Math.sqrt(c())*.5},f=new Float32Array(i*3),p=new Float32Array(i*3),m=new Float32Array(i),h=new Float32Array(i),g=new Float32Array(i),y=(e,t,n,r,i,a)=>{f[e*3]=t,f[e*3+1]=n,f[e*3+2]=r,c()<.18?vi.copy(gi):vi.copy(mi).lerp(hi,c()),p[e*3]=vi.r,p[e*3+1]=vi.g,p[e*3+2]=vi.b,m[e]=i,h[e]=a*ci,g[e]=c()*Math.PI*2},b=0;for(let e=0;e<s;e+=1,b+=1){let e=d(),t=n?Te(Math.floor(c()*3)%3,e)+u()*I(e)*1.3:c()*Math.PI*2;y(b,Math.cos(t)*e,u()*se(e)*oi,Math.sin(t)*e*he,.6+c()*c()*2,.35+c()*.35)}for(let e=0;e<a;e+=1,b+=1){let e=8.4;y(b,u()*e,u()*5,u()*e*he,.9+c()*1.7,(.4+c()*.3)*li)}for(let e=0;e<o;e+=1,b+=1){let e=d(),t=c()*Math.PI*2;y(b,Math.cos(t)*e,u()*se(e)*oi,Math.sin(t)*e*he,.6+c()*1.2,.35+c()*.15)}let x=new v;return x.setAttribute(`position`,new _(f,3)),x.setAttribute(`aColor`,new _(p,3)),x.setAttribute(`aSize`,new _(m,1)),x.setAttribute(`aAlpha`,new _(h,1)),x.setAttribute(`aSeed`,new _(g,1)),x},[e,t,n]);(0,R.useEffect)(()=>()=>s.dispose(),[s]);let c=(0,R.useMemo)(()=>({uMap:{value:Be()},uScale:{value:270},uTime:{value:0},uWarp:{value:0},uSpread:{value:1}}),[]);return C(e=>{let t=r?.current??0,n=i.current?.uniforms;n&&(n.uTime.value=e.clock.elapsedTime,n.uWarp.value=t,n.uSpread.value=_t(),n.uScale.value=e.size.height*.3);let s=(1-.6*t)*_t();a.current&&(a.current.opacity=ui*s),o.current&&(o.current.opacity=di*s)}),(0,q.jsxs)(`group`,{renderOrder:0,children:[(0,q.jsx)(`sprite`,{scale:[fi,fi,1],raycast:()=>null,renderOrder:0,children:(0,q.jsx)(`spriteMaterial`,{ref:a,map:ze(),color:_i,transparent:!0,opacity:ui,depthWrite:!1,blending:2,toneMapped:!1,fog:!1})}),(0,q.jsx)(`sprite`,{scale:[pi,pi,1],raycast:()=>null,renderOrder:0,children:(0,q.jsx)(`spriteMaterial`,{ref:o,map:ze(),color:_i,transparent:!0,opacity:di,depthWrite:!1,blending:2,toneMapped:!1,fog:!1})}),(0,q.jsx)(`points`,{geometry:s,frustumCulled:!1,raycast:()=>null,renderOrder:0,children:(0,q.jsx)(`shaderMaterial`,{ref:i,uniforms:c,vertexShader:bi,fragmentShader:xi,transparent:!0,depthWrite:!1,blending:2,toneMapped:!1})})]})}var bi=`
  attribute vec3 aColor;
  attribute float aSize;
  attribute float aAlpha;
  attribute float aSeed;
  uniform float uScale;
  uniform float uTime;
  uniform float uWarp;
  uniform float uSpread;
  varying vec3 vColor;
  varying float vAlpha;
  void main(){
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = clamp(aSize * (uScale / -mv.z), 0.6, 4.0);
    // 아주 느린 반짝임 — 알파만 ±25% 흔들어 '살아 있는' 배경을 만든다
    vColor = aColor;
    vAlpha = aAlpha * (1.0 + 0.25 * sin(uTime * 0.6 + aSeed)) * mix(1.0, ${si.toFixed(2)}, uWarp) * uSpread;
    gl_Position = projectionMatrix * mv;
  }
`,xi=`
  uniform sampler2D uMap;
  varying vec3 vColor;
  varying float vAlpha;
  void main(){
    float a = texture2D(uMap, gl_PointCoord).a * vAlpha;
    if (a < 0.004) discard;
    gl_FragColor = vec4(vColor, a);
  }
`,Si=256,Ci=.45,wi=80,Ti=1,Ei=e=>e*e,Di=new r,Oi=new w;function ki(){let e=(0,R.useRef)(null),t=(0,R.useMemo)(()=>{let e=new ee(1,1).toNonIndexed();return e.computeVertexNormals(),e},[]);(0,R.useEffect)(()=>()=>t.dispose(),[t]);let n=Re(3),r=(0,R.useRef)(null);return(0,R.useEffect)(()=>{let t=e.current;t&&(t.count=0,t.instanceMatrix.setUsage(p))},[]),C(()=>{let t=e.current;if(!t)return;let n=V.plan;if(!n||n.ghosts.length===0){r.current=null,t.count=0,t.visible=!1;return}let i=Math.min(Si,n.ghosts.length);if(r.current!==n){r.current=n;for(let e=0;e<i;e+=1)Oi.set(n.ghosts[e].color),t.setColorAt(e,Oi);t.instanceColor&&(t.instanceColor.needsUpdate=!0)}let a=Math.min(1,n.t*n.dur/Ci);if(a>=1){t.count=0,t.visible=!1;return}let o=Ei(a)*wi,s=(1-a)**1.5;for(let e=0;e<i;e+=1){let r=n.ghosts[e];Di.position.set(r.pos[0]+r.dir[0]*o,r.pos[1]+r.dir[1]*o,r.pos[2]+r.dir[2]*o),Di.scale.setScalar(Math.max(.001,r.radius*s)),Di.updateMatrix(),t.setMatrixAt(e,Di.matrix)}t.count=i,t.visible=!0,t.instanceMatrix.needsUpdate=!0}),(0,q.jsx)(`instancedMesh`,{ref:e,args:[t,void 0,Si],frustumCulled:!1,raycast:()=>null,visible:!1,renderOrder:2,onUpdate:e=>e.layers.enable(Ti),children:(0,q.jsx)(`meshToonMaterial`,{color:`#ffffff`,gradientMap:n})})}var Ai=1.25,ji=2.4,Mi=.25,Ni=10,Pi=150,Fi=250,Ii=60,Li=1e-6,Ri=new Set([`ArrowUp`,`ArrowDown`,`ArrowLeft`,`ArrowRight`]),zi=new Set([`KeyW`,`KeyA`,`KeyS`,`KeyD`]),Bi=new o,Vi=new u,Hi=new o,Ui=new o,Wi=new o(0,1,0),Gi=new o,Ki=new o,qi=new o,Ji=new o;function Yi({bound:e=Fi}){let n=j(e=>e.camera),r=j(e=>e.controls),i=(0,R.useRef)({keys:new Set,vel:new a,pan:new o,shift:!1});return(0,R.useEffect)(()=>{let e=i.current,t=()=>e.keys.clear(),n=n=>{if(e.shift=n.shiftKey,n.metaKey){t();return}let r=ke(n),i=Ri.has(r);if(!i&&!zi.has(r)||n.altKey||n.ctrlKey)return;let a=L.getState();a.searchOpen||a.industryOpen||ce.getState().helpOpen||Ne()||(!De()||!i&&je())&&(i&&(je()||ge(r===`ArrowUp`||r===`ArrowDown`?`y`:`x`))||(e.keys.add(r),i&&n.preventDefault()))},r=n=>{e.shift=n.shiftKey,n.metaKey||n.key===`Meta`?t():e.keys.delete(ke(n))},a=()=>{document.visibilityState===`hidden`&&t()};return window.addEventListener(`keydown`,n),window.addEventListener(`keyup`,r),window.addEventListener(`blur`,t),window.addEventListener(`contextmenu`,t),document.addEventListener(`visibilitychange`,a),()=>{window.removeEventListener(`keydown`,n),window.removeEventListener(`keyup`,r),window.removeEventListener(`blur`,t),window.removeEventListener(`contextmenu`,t),document.removeEventListener(`visibilitychange`,a)}},[]),C((a,o)=>{let s=L.getState();if(!r)return;let c=i.current,l=Math.min(o,.05);if(!r.enabled||s.searchOpen){s.searchOpen&&c.keys.clear(),c.vel.set(0,0),c.pan.set(0,0,0);return}let u=c.keys,d=c.shift?ji:1,f=1-.002**l,p=0,m=0;if(u.has(`ArrowLeft`)&&--p,u.has(`ArrowRight`)&&(p+=1),u.has(`ArrowUp`)&&--m,u.has(`ArrowDown`)&&(m+=1),c.vel.x+=(p*Ai*d-c.vel.x)*f,c.vel.y+=(m*Ai*d-c.vel.y)*f,Hi.copy(r.target).sub(n.position),Hi.y=0,Hi.lengthSq()<1e-8?Hi.set(0,0,-1):Hi.normalize(),Ui.crossVectors(Hi,Wi),Gi.set(0,0,0),u.has(`KeyW`)&&Gi.add(Hi),u.has(`KeyS`)&&Gi.sub(Hi),u.has(`KeyD`)&&Gi.add(Ui),u.has(`KeyA`)&&Gi.sub(Ui),Gi.lengthSq()>0){let e=t.clamp(n.position.distanceTo(r.target)*Mi,Ni,Pi)*d;Gi.normalize().multiplyScalar(e)}c.pan.lerp(Gi,f);let h=Math.abs(c.vel.x)>=1e-4||Math.abs(c.vel.y)>=1e-4,g=c.pan.lengthSq()>=1e-6;if(h||c.vel.set(0,0),g||c.pan.set(0,0,0),h||g){if(h){Bi.copy(n.position).sub(r.target),Vi.setFromVector3(Bi),Vi.theta+=c.vel.x*l;let e=Math.min(Math.max(r.minPolarAngle,Li),Vi.phi),i=Math.max(Math.min(r.maxPolarAngle,Math.PI-Li),Vi.phi),a=Vi.phi+c.vel.y*l;Vi.phi=t.clamp(a,e,i),Vi.phi!==a&&(c.vel.y=0),n.position.copy(r.target).add(Bi.setFromSpherical(Vi))}if(g){Ki.copy(r.target).addScaledVector(c.pan,l);let t=Math.max(e,Ii,Math.hypot(r.target.x,r.target.z)),i=Math.hypot(Ki.x,Ki.z);if(i>t){Ki.x*=t/i,Ki.z*=t/i,Ji.set(Ki.x,0,Ki.z).normalize();let e=c.pan.dot(Ji);e>0&&c.pan.addScaledVector(Ji,-e)}qi.copy(Ki).sub(r.target),r.target.copy(Ki),n.position.add(qi)}n.lookAt(r.target)}}),null}var Xi=96,Zi=`#8FA6C8`,Qi=[`#F4D9A0`,`#D9B36C`,`#A9824C`],$i=.07,ea=.05,ta=.08,na=[.25,.5,.75,1],ra=.82,ia=-Math.PI/3,aa=220,oa=.4,sa=.15,ca=4;function la({model:e}){let t=(0,R.useRef)(null),n=L(e=>e.altitudeOn),r=(0,R.useRef)({}),i=(0,R.useRef)({}),a=(0,R.useRef)(1),o=(0,R.useRef)(1),s=(0,R.useMemo)(()=>{let e=new v,t=new Float32Array(288);for(let e=0;e<Xi;e+=1){let n=e/Xi*Math.PI*2;t[e*3]=Math.cos(n),t[e*3+1]=0,t[e*3+2]=Math.sin(n)}return e.setAttribute(`position`,new _(t,3)),e},[]);(0,R.useEffect)(()=>()=>s.dispose(),[s]);let c=(0,R.useMemo)(()=>{if(e.kind!==`galaxy`||!e.nodes.length)return null;let t=e.nodes.slice().sort((e,t)=>(t.weight??t.degree)-(e.weight??e.degree)),n=t.length,r=e=>Math.hypot(e.pos[0],e.pos[2]/he),i=Ee.hubPercents.map(e=>r(t[Math.min(n-1,Math.max(0,Math.round(e/100*(n-1))))])),a=e.nodes.map(e=>e.pos[1]).sort((e,t)=>e-t);return{hub:i,midY:a[Math.floor((a.length-1)/2)],maxR:e.extent.maxR}},[e]),l=(0,R.useMemo)(()=>{if(e.kind!==`system`)return[];let t=new Map;e.nodes.forEach(e=>{if(e.depth<1||e.depth>3)return;let n=Math.hypot(e.pos[0],e.pos[2]/ra);t.has(e.depth)||t.set(e.depth,[]),t.get(e.depth).push(n)});let n=[];for(let e=1;e<=3;e+=1){let r=t.get(e);r?.length&&(r.sort((e,t)=>e-t),n.push({depth:e,r:r[Math.floor((r.length-1)/2)]}))}return n},[e]);return C((e,n)=>{let s=t.current;if(!s)return;let c=Math.min(n,.05),l=L.getState().phase===`warp`;if(s.visible=!l,l){Object.values(i.current).forEach(e=>{e.style.opacity=`0`});return}let u=V.plan?0:V.reveal;o.current+=(u-o.current)*(1-Math.exp(-c/sa));let d=_t();Object.values(r.current).forEach(({mat:e,base:t})=>{e.opacity=t*o.current*d});let f=+(e.camera.position.length()>=aa);a.current+=(f-a.current)*(1-Math.exp(-c/oa));let p=a.current*o.current*d,m=o.current;Object.entries(i.current).forEach(([e,t])=>{t.style.opacity=String(e.startsWith(`hub`)?p:m)})}),(0,q.jsxs)(`group`,{ref:t,children:[c?.hub.map((e,t)=>(0,q.jsxs)(`group`,{position:[0,c.midY,0],children:[(0,q.jsx)(`lineLoop`,{geometry:s,scale:[e,1,e*he],frustumCulled:!1,renderOrder:0,ref:e=>{let n=`hub${t}`;e?r.current[n]={mat:e.material,base:$i}:delete r.current[n]},children:(0,q.jsx)(`lineBasicMaterial`,{color:Qi[t],transparent:!0,opacity:$i,depthWrite:!1})}),(0,q.jsx)(k,{position:[Math.cos(ia)*e,0,Math.sin(ia)*e*he],pointerEvents:`none`,zIndexRange:[3,0],className:`ring-label ring-label-hub ring-label-hub-${t}`,children:(0,q.jsx)(`div`,{ref:e=>{let n=`hub${t}`;e?i.current[n]=e:delete i.current[n]},children:Ee.hub(Ee.hubPercents[t])})})]},`hub-${t}`)),c&&n&&(0,q.jsxs)(`group`,{position:[0,c.midY,0],children:[na.map((e,t)=>(0,q.jsx)(`lineLoop`,{geometry:s,scale:[c.maxR*e,1,c.maxR*e],frustumCulled:!1,renderOrder:0,ref:e=>{let n=`zero${t}`;e?r.current[n]={mat:e.material,base:ea}:delete r.current[n]},children:(0,q.jsx)(`lineBasicMaterial`,{color:Zi,transparent:!0,opacity:ea,depthWrite:!1})},`zero-${t}`)),(0,q.jsx)(k,{position:[c.maxR*1.02,0,0],pointerEvents:`none`,zIndexRange:[3,0],className:`ring-label`,children:(0,q.jsx)(`div`,{ref:e=>{e?i.current.zero=e:delete i.current.zero},children:Ee.zeroPlane})})]}),l.map(({depth:e,r:t})=>(0,q.jsxs)(`group`,{children:[(0,q.jsx)(`lineLoop`,{geometry:s,scale:[t,1,t*ra],frustumCulled:!1,renderOrder:0,ref:t=>{let n=`d${e}`;t?r.current[n]={mat:t.material,base:ta}:delete r.current[n]},children:(0,q.jsx)(`lineBasicMaterial`,{color:Zi,transparent:!0,opacity:ta,depthWrite:!1})}),(0,q.jsx)(k,{position:[0,0,-(t*ra+ca)],pointerEvents:`none`,zIndexRange:[3,0],className:`ring-label`,children:(0,q.jsx)(`div`,{ref:t=>{let n=`d${e}`;t?i.current[n]=t:delete i.current[n]},children:Ee.depth[e-1]})})]},`depth-${e}`))]})}var ua=22,da=6,fa=2,pa=8,$=new o,ma=new w,ha=new S(new o,new o,new o),ga=2.2,_a=1.4,va=[.35,.95],ya=.35,ba=.9,xa=new WeakMap,Sa=new WeakMap,Ca=.001;function wa(e,t){let n=new Set;return e.nodes.forEach((e,r)=>{let i=r*3;(Math.abs(t.pos[i]-e.pos[0])>Ca||Math.abs(t.pos[i+1]-e.pos[1])>Ca||Math.abs(t.pos[i+2]-e.pos[2])>Ca)&&n.add(e.id)}),n}function Ta(e,t,n,r,a,o,s){let c=new Set;if(s.forEach(e=>n.get(e)?.forEach(e=>c.add(e))),!c.size)return;let{fromArr:l,toArr:u,position:d,normal:f,pickPos:p,ctrls:m,radii:h,vPer:g}=e;c.forEach(e=>{let n=t[e],s=r.get(n.source),c=r.get(n.target);if(s===void 0||c===void 0)return;for(let t=0;t<3;t+=1)l[e*3+t]=a.pos[s*3+t],u[e*3+t]=a.pos[c*3+t];let _=m[e];_r(l,u,_,e*3,e*3,o),ha.v0.fromArray(l,e*3),ha.v1.copy(_),ha.v2.fromArray(u,e*3);let v=new i(ha,ua,h[e],da,!1);d.set(v.attributes.position.array,e*g*3),f.set(v.attributes.normal.array,e*g*3),v.dispose();for(let t=0;t<pa;t+=1){let n=(e*pa+t)*6;vr(l,u,_,t/pa,$,e*3,e*3),p[n]=$.x,p[n+1]=$.y,p[n+2]=$.z,vr(l,u,_,(t+1)/pa,$,e*3,e*3),p[n+3]=$.x,p[n+4]=$.y,p[n+5]=$.z}}),St(e.posAttr,e.normAttr,e.pickAttr),e.pick.computeBoundingSphere()}var Ea=e=>e<0?0:e>1?1:e,Da=(e,t,n)=>{let r=Ea((n-e)/(t-e));return r*r*(3-2*r)},Oa=(e,t)=>Ea((e-(1-t)*ya)/.65);function ka({edges:e,emphasis:t,model:n,onHover:r,onSelect:a,intensity:s=1,hoveredEdgeId:c=null,warpFx:l=!1}){let u=n?ur[n.kind]:0,d=(0,R.useMemo)(()=>{let t=e.length,n=[],r=new Float32Array(t),a=new Float32Array(t),s=new Float32Array(t),c=new Float32Array(t*3),l=new Float32Array(t*3),d=new Float32Array(t*161*3),f=new Float32Array(t*161*3),m=new Float32Array(t*161),h=new Float32Array(t*161),g=new Uint8Array(t),y=new Float32Array(t*161),b=new Float32Array(t*161),x=new Float32Array(t*161),C=new Float32Array(t*161*3),w=new Float32Array(t*161).fill(1),T=new Uint32Array(t*792),E=new Float32Array(t*pa*2*3),D=new Float32Array(t*3);e.forEach((e,t)=>{c.set(e.from,t*3),l.set(e.to,t*3);let p=new o;_r(e.from,e.to,p,0,0,u),n.push(p);let _=e.score/100,v=yr(_);r[t]=v,a[t]=.05+_*.14,s[t]=t*.6180339887%1,ma.setStyle(fe(e.type),``),D[t*3]=ma.r,D[t*3+1]=ma.g,D[t*3+2]=ma.b;let w=new S(new o().fromArray(e.from),p,new o().fromArray(e.to)),O=new i(w,ua,v,da,!1),k=O.attributes.position.array,A=O.attributes.normal.array,j=O.attributes.uv.array,ee=O.index.array,M=t*161;d.set(k,M*3),f.set(A,M*3);let N=+(Math.hypot(e.from[0],e.from[1],e.from[2])<=Math.hypot(e.to[0],e.to[1],e.to[2]));g[t]=N;for(let n=0;n<161;n+=1)m[M+n]=j[n*2],h[M+n]=N?j[n*2]:1-j[n*2],y[M+n]=_,b[M+n]=v,x[M+n]=+!!e.directed,C[(M+n)*3]=D[t*3],C[(M+n)*3+1]=D[t*3+1],C[(M+n)*3+2]=D[t*3+2];let P=t*792;for(let e=0;e<792;e+=1)T[P+e]=ee[e]+M;O.dispose();for(let n=0;n<pa;n+=1){let r=(t*pa+n)*6;vr(e.from,e.to,p,n/pa,$),E[r]=$.x,E[r+1]=$.y,E[r+2]=$.z,vr(e.from,e.to,p,(n+1)/pa,$),E[r+3]=$.x,E[r+4]=$.y,E[r+5]=$.z}});let O=new v,k=new _(d,3);k.setUsage(p);let A=new _(f,3);A.setUsage(p),O.setAttribute(`position`,k),O.setAttribute(`normal`,A),O.setAttribute(`aT`,new _(m,1)),O.setAttribute(`aT2`,new _(h,1)),O.setAttribute(`aScore`,new _(y,1)),O.setAttribute(`aRadius`,new _(b,1)),O.setAttribute(`aFlow`,new _(x,1)),O.setAttribute(`aColor`,new _(C,3));let j=new _(w,1);j.setUsage(p),O.setAttribute(`aEmph`,j),O.setIndex(new _(T,1)),O.computeBoundingSphere();let ee=new v,M=new _(E,3);M.setUsage(p),ee.setAttribute(`position`,M);let N=t*fa,P=new v,te=new _(new Float32Array(N*3),3);te.setUsage(p);let ne=new _(new Float32Array(N),1);ne.setUsage(p);let F=new _(new Float32Array(N),1);F.setUsage(p);let I=new Float32Array(N*3);for(let e=0;e<t;e+=1)for(let t=0;t<fa;t+=1){let n=(e*fa+t)*3;I[n]=D[e*3],I[n+1]=D[e*3+1],I[n+2]=D[e*3+2]}return P.setAttribute(`position`,te),P.setAttribute(`aSize`,ne),P.setAttribute(`aAlpha`,F),P.setAttribute(`aColor`,new _(I,3)),{geo:O,emphAttr:j,posAttr:k,normAttr:A,pick:ee,pickAttr:M,position:d,normal:f,pickPos:E,fromArr:c,toArr:l,ctrls:n,radii:r,speeds:a,phases:s,outward:g,pulseGeo:P,pPos:te,pSize:ne,pAlpha:F,vPer:161}},[e,u]);(0,R.useEffect)(()=>()=>{d.geo.dispose(),d.pick.dispose(),d.pulseGeo.dispose()},[d]),(0,R.useEffect)(()=>{let n=d.emphAttr.array;e.forEach((e,r)=>{let i=t.edge.get(e.id)??1;n.fill(i,r*d.vPer,(r+1)*d.vPer)}),d.emphAttr.needsUpdate=!0},[e,t,d]);let f=(0,R.useMemo)(()=>{let t=new Map,n=(e,n)=>{let r=t.get(e);r?r.push(n):t.set(e,[n])};return e.forEach((e,t)=>{n(e.source,t),n(e.target,t)}),t},[e]),m=(0,R.useMemo)(()=>{let e=new Map;return n?.nodes.forEach((t,n)=>e.set(t.id,n)),e},[n]),h=(0,R.useMemo)(()=>({uDim:{value:1},uInflate:{value:0},uHalo:{value:0},uFade:{value:1},uReveal:{value:1}}),[]),g=(0,R.useMemo)(()=>({uDim:{value:1},uInflate:{value:1.7},uHalo:{value:1},uFade:{value:1},uReveal:{value:1}}),[]),y=(0,R.useMemo)(()=>({uDim:{value:1},uScale:{value:600}}),[]);C((r,i)=>{let a=Math.min(i,.05),o=Sa.get(d);if(o||(o={version:B.version,catchUp:!0},Sa.set(d,o)),n&&!V.plan){let t=$e(n);o.version===B.version?o.catchUp&&!z.animating&&!H.animating&&(o.catchUp=!1,Ta(d,e,f,m,t,u,wa(n,t))):(o.catchUp=!1,o.version=B.version,Ta(d,e,f,m,t,u,B.dirty))}let p=l?_t():1;h.uDim.value=s*p,g.uDim.value=s*p,y.uDim.value=s*p,y.uScale.value=r.size.height*.62;let _=xa.get(d);_||(_={born:r.clock.elapsedTime,reveal:+!l},xa.set(d,_));let v=l?Ze():{fade:1,reveal:1},b=l?gt():{fade:1,reveal:1},x=_.reveal=l?V.plan?0:Math.min(V.reveal,v.reveal,b.reveal,Da(va[0],va[1],r.clock.elapsedTime-_.born)):1,S=l?Math.min(V.fade,v.fade,b.fade):1;h.uFade.value=S,g.uFade.value=S,h.uReveal.value=x,g.uReveal.value=x;let C=d.pPos.array,w=d.pSize.array,T=d.pAlpha.array;e.forEach((e,n)=>{let r=t.edge.get(e.id)??1,i=d.ctrls[n],o=e.id===c,s=d.phases[n]=(d.phases[n]+a*d.speeds[n]*(o?ga:1))%1,l=x>=1?1:Oa(x,e.score/100);for(let t=0;t<fa;t+=1){let a=n*fa+t,c=(s+t/fa)%1;!e.directed&&t%2==1&&(c=1-c),vr(d.fromArr,d.toArr,i,c,$,n*3,n*3),C[a*3]=$.x,C[a*3+1]=$.y,C[a*3+2]=$.z;let u=Math.sin(c*Math.PI);w[a]=d.radii[n]*(6+u*3.6)*(o?_a:1);let f=(d.outward[n]?c:1-c)<=l;T[a]=r<=.003||!f?0:(.35+.65*u)*Math.min(1,r*1.4)*S}}),d.pPos.needsUpdate=!0,d.pSize.needsUpdate=!0,d.pAlpha.needsUpdate=!0});let b=()=>xa.get(d)?.reveal??1,x=t=>{let n=t.index??0;return e[Math.floor(n/16)]},w=e=>e.intersections.some(e=>e.object.userData?.pick===`node`);return(0,q.jsxs)(`group`,{children:[(0,q.jsx)(`mesh`,{geometry:d.geo,frustumCulled:!1,raycast:()=>null,renderOrder:2,children:(0,q.jsx)(`shaderMaterial`,{uniforms:h,vertexShader:Aa,fragmentShader:ja,transparent:!0,depthWrite:!1,toneMapped:!1})}),(0,q.jsx)(`mesh`,{geometry:d.geo,frustumCulled:!1,raycast:()=>null,renderOrder:1,children:(0,q.jsx)(`shaderMaterial`,{uniforms:g,vertexShader:Aa,fragmentShader:ja,transparent:!0,depthWrite:!1,blending:2,toneMapped:!1})}),(0,q.jsx)(`points`,{geometry:d.pulseGeo,frustumCulled:!1,raycast:()=>null,renderOrder:3,children:(0,q.jsx)(`shaderMaterial`,{uniforms:y,transparent:!0,depthWrite:!1,blending:2,toneMapped:!1,vertexShader:Ma,fragmentShader:Na})}),(0,q.jsx)(`lineSegments`,{geometry:d.pick,frustumCulled:!1,onPointerMove:e=>{if(b()<ba||B.id)return;if(w(e)){r?.(null);return}e.stopPropagation();let n=x(e);n&&(t.edge.get(n.id)??1)>.003&&r?.(n.id)},onPointerOut:()=>r?.(null),onClick:e=>{if(b()<ba||B.blockClick||w(e))return;e.stopPropagation();let n=x(e);n&&(t.edge.get(n.id)??1)>.003&&a?.(n.id)},children:(0,q.jsx)(`lineBasicMaterial`,{transparent:!0,opacity:0,depthWrite:!1})})]})}var Aa=`
  attribute float aT;
  attribute float aT2;
  attribute float aScore;
  attribute float aRadius;
  attribute float aFlow;
  attribute vec3 aColor;
  attribute float aEmph;
  uniform float uInflate;
  varying float vT;
  varying float vT2;
  varying float vScore;
  varying float vFlow;
  varying vec3 vColor;
  varying float vEmph;
  varying vec3 vNormalV;
  void main(){
    vT = aT; vT2 = aT2; vScore = aScore; vFlow = aFlow; vColor = aColor; vEmph = aEmph;
    // 헤일로 패스는 법선 방향으로 부풀린다
    vec3 p = position + normal * aRadius * uInflate;
    vNormalV = normalize(normalMatrix * normal);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`,ja=`
  uniform float uDim;
  uniform float uHalo;
  uniform float uFade;
  uniform float uReveal;
  varying float vT;
  varying float vT2;
  varying float vScore;
  varying float vFlow;
  varying vec3 vColor;
  varying float vEmph;
  varying vec3 vNormalV;
  void main(){
    if (vEmph <= 0.003 || uFade <= 0.003) discard;
    // 리빌: 점수 높은 빔이 먼저(rv), 각 빔은 원점에 가까운 끝(vT2=0)에서 바깥으로 자란다
    float rv = clamp((uReveal - (1.0 - vScore) * 0.35) / 0.65, 0.0, 1.0);
    float grow = 1.0 - smoothstep(rv - 0.06, rv, vT2);
    if (grow <= 0.003) discard;
    // 무방향 관계는 점선
    float dash = vFlow > 0.5 ? 1.0 : mix(0.3, 1.0, step(0.5, fract(vT * 18.0)));
    // 끝점은 행성에 묻히도록 살짝 페이드
    float ends = smoothstep(0.0, 0.05, vT) * smoothstep(1.0, 0.95, vT);
    vec3 col = vColor;
    if (uHalo > 0.5) {
      float a = 0.14 * (0.5 + 0.5 * vScore) * vEmph * vEmph * dash * ends * uDim * uFade * grow;
      // 헤일로는 본체와 같은 색을 가산 합성한다 — 조금만 흰색을 섞어 번짐이 색을 덧칠하지 않고 빛으로 읽히게
      gl_FragColor = vec4(mix(col, vec3(1.0), 0.15), a);
      return;
    }
    // 플랫 컬러 + 살짝의 원통 음영 (툰 느낌)
    float shade = 0.8 + 0.2 * max(0.0, dot(normalize(vNormalV), normalize(vec3(-0.45, 0.75, 0.6))));
    col *= shade;
    // 흐린 간선은 색을 탁하게 하지 않고 투명도만 낮춘다 (갈색 띠 방지)
    col *= mix(0.85, 1.0, vEmph);
    float a = (0.55 + 0.45 * vScore) * vEmph * vEmph * dash * ends * mix(0.55, 1.0, uDim) * uFade * grow;
    gl_FragColor = vec4(col, a);
  }
`,Ma=`
  attribute float aSize;
  attribute float aAlpha;
  attribute vec3 aColor;
  uniform float uScale;
  varying float vAlpha;
  varying vec3 vColor;
  void main(){
    vAlpha = aAlpha; vColor = aColor;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = aSize * (uScale / -mv.z);
    gl_Position = projectionMatrix * mv;
  }
`,Na=`
  uniform float uDim;
  varying float vAlpha;
  varying vec3 vColor;
  void main(){
    if (vAlpha <= 0.002) discard;
    float d = length(gl_PointCoord - 0.5) * 2.0;
    if (d > 1.0) discard;
    // 밝은 크림색 심 + 간선 색 글로우 — 심을 색과 무관하게 두어야 어떤 색 빔에서도 구슬이 '빛나는 알갱이'로 보인다
    float core = smoothstep(0.36, 0.18, d);
    float glow = exp(-d * d * 3.2) * 0.55;
    vec3 col = mix(vColor, vec3(1.0, 0.95, 0.86), core);
    gl_FragColor = vec4(col * (core + glow), (core + glow) * vAlpha * uDim);
  }
`,Pa=64,Fa=2.4,Ia=.9,La=new o,Ra=new o,za=new o,Ba=new o,Va=new o,Ha=new r,Ua=new w;function Wa({model:e,hoveredId:t,roles:n}){let r=(0,R.useRef)(null),i=$e(e),a=(0,R.useMemo)(()=>{let e=new l(2,2),t=(e,t)=>{let n=new P(e,t);return n.setUsage(p),n},n=t(new Float32Array(192),3),r=t(new Float32Array(Pa),1),i=t(new Float32Array(Pa),1),a=t(new Float32Array(Pa),1);return e.setAttribute(`aColor`,n),e.setAttribute(`aDir`,r),e.setAttribute(`aAngle`,i),e.setAttribute(`aAlpha`,a),{geo:e,color:n,dir:r,angle:i,alpha:a}},[]);(0,R.useEffect)(()=>()=>a.geo.dispose(),[a]);let o=(0,R.useRef)({model:e,roles:null,idx:[],alpha:new Float32Array(Pa)});return C((s,c)=>{let l=r.current;if(!l)return;let u=o.current;u.model!==e&&(u.model=e,u.roles=null,u.idx=[],u.alpha.fill(0));let d=1-1e-4**(Math.min(c,.05)*2),f=s.camera,p=L.getState().phase===`warp`;if(n!==u.roles&&(u.roles=n,n)){let t=[];n.forEach((n,r)=>{let i=e.nodeById.get(r);i&&t.push(e.nodes.indexOf(i))}),t.sort((t,n)=>e.nodes[n].size-e.nodes[t].size),u.idx=t.slice(0,Pa),u.alpha.fill(0);let r=a.color.array,i=a.dir.array;u.idx.forEach((t,a)=>{let o=n.get(e.nodes[t].id);Ua.set(ie(o)),r[a*3]=Ua.r,r[a*3+1]=Ua.g,r[a*3+2]=Ua.b;let s=ae[o].dir;i[a]=s===`in`?1:s===`out`?2:0}),St(a.color,a.dir)}let m=t?e.nodeById.get(t):void 0,h=m?e.nodes.indexOf(m):-1,g=n&&h>=0&&!p&&!V.plan?Ia:0;h>=0&&Ra.fromArray(i.pos,h*3),Ba.set(0,1,0).applyQuaternion(f.quaternion),Va.set(1,0,0).applyQuaternion(f.quaternion);let _=a.alpha.array,v=a.angle.array,y=!1;u.idx.forEach((t,n)=>{let r=u.alpha[n]+=(g-u.alpha[n])*d;if(_[n]=r,r<.01)Ha.position.set(0,0,0),Ha.scale.setScalar(.001);else{y=!0;let r=e.nodes[t];La.fromArray(i.pos,t*3);let a=r.size*3*En(r.id).scale*i.scale[t];Ha.position.copy(La),Ha.quaternion.copy(f.quaternion),Ha.scale.setScalar(a*Fa),h>=0&&(za.subVectors(Ra,La),v[n]=Math.atan2(za.dot(Ba),za.dot(Va)))}Ha.updateMatrix(),l.setMatrixAt(n,Ha.matrix)}),l.count=y?u.idx.length:0,l.visible=y,y&&(l.instanceMatrix.needsUpdate=!0,St(a.alpha,a.angle))}),(0,q.jsx)(`instancedMesh`,{ref:r,args:[a.geo,void 0,Pa],frustumCulled:!1,renderOrder:4,raycast:()=>null,visible:!1,children:(0,q.jsx)(`shaderMaterial`,{vertexShader:Ga,fragmentShader:Ka,transparent:!0,depthTest:!1,depthWrite:!1,blending:1,toneMapped:!1})})}var Ga=`
  attribute vec3 aColor;
  attribute float aDir;
  attribute float aAngle;
  attribute float aAlpha;
  varying vec2 vP;
  varying vec3 vColor;
  varying float vDir;
  varying float vAngle;
  varying float vAlpha;
  void main() {
    vP = uv * 2.0 - 1.0;
    vColor = aColor; vDir = aDir; vAngle = aAngle; vAlpha = aAlpha;
    gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(position, 1.0);
  }
`,Ka=`
  varying vec2 vP;
  varying vec3 vColor;
  varying float vDir;
  varying float vAngle;
  varying float vAlpha;
  void main() {
    if (vAlpha < 0.01) discard;
    float r = length(vP);
    float aa = max(fwidth(r), 1e-4) * 1.2;
    // 링 r ∈ [0.72, 0.86]
    float ring = smoothstep(0.72 - aa, 0.72 + aa, r) * (1.0 - smoothstep(0.86 - aa, 0.86 + aa, r));
    // 무방향은 점선 (12 칸)
    if (vDir < 0.5) ring *= step(0.5, fract(atan(vP.y, vP.x) / 6.2831853 * 12.0));
    // 쐐기: 호버 방향이 +x 가 되도록 돌린 좌표에서 x 축 위 삼각형.
    // in(1) 은 밑변 0.55 → 꼭짓점 1.0 (호버 노드를 가리킴), out(2) 은 밑변 1.0 → 꼭짓점 0.55 (이웃 안쪽)
    float wedge = 0.0;
    if (vDir > 0.5) {
      float c = cos(-vAngle);
      float s = sin(-vAngle);
      vec2 q = vec2(c * vP.x - s * vP.y, s * vP.x + c * vP.y);
      float bx = vDir < 1.5 ? 0.55 : 1.0;
      float tx = vDir < 1.5 ? 1.0 : 0.55;
      float u = (q.x - bx) / (tx - bx);
      float hw = 0.16 * (1.0 - u);
      wedge = step(0.0, u) * step(u, 1.0) * (1.0 - smoothstep(hw - aa, hw + aa, abs(q.y)));
    }
    float a = max(ring, wedge) * vAlpha;
    if (a < 0.004) discard;
    gl_FragColor = vec4(vColor, a);
  }
`,qa=.01,Ja=e=>e<.5?2*e*e:1-(-2*e+2)**2/2;function Ya(e){B.dirty.clear(),e.nodes.forEach(e=>B.dirty.add(e.id)),B.version+=1}function Xa({model:e}){let t=(0,R.useMemo)(()=>{let t=new Map;return e.nodes.forEach((e,n)=>t.set(e.id,n)),t},[e]),n=(0,R.useRef)({model:null,applied:NaN,from:new Float32Array,to:new Float32Array,base:new Float32Array,skip:new Set,lastVersion:B.version,rebuilt:!1}).current;return(0,R.useEffect)(()=>()=>{H.animating=!1,H.t=0,H.applied=NaN},[]),C((r,i)=>{let a=Math.min(i,.05),o=L.getState(),s=$e(e);if(n.model!==e&&(n.model=e,n.from=new Float32Array(e.nodes.length*3),n.to=new Float32Array(e.nodes.length*3),n.base=new Float32Array(e.nodes.length*3),n.skip.clear(),n.rebuilt=!1,n.applied=NaN,H.animating=!1,H.t=0,H.applied=NaN),V.plan){n.lastVersion=B.version,H.applied=n.applied;return}let c=e.nodes.length,l=o.spread,u=B.id!==null||B.version!==n.lastVersion||V.plan!==null||z.animating;n.lastVersion=B.version;let d=()=>{for(let t=0;t<c;t+=1){let r=e.nodes[t];n.base[t*3]=r.pos[0],n.base[t*3+1]=o.altitudeOn?qe(r,o.altitudeWindow):r.pos[1],n.base[t*3+2]=r.pos[2]}};if(Number.isNaN(n.applied)){d(),be(e,l,n.base,n.to);let t=!1;for(let e=0;e<c*3;e+=1)Math.abs(n.to[e]-s.pos[e])>qa&&(t=!0),s.pos[e]=n.to[e];n.applied=l,t&&(Ya(e),n.lastVersion=B.version)}else l!==n.applied&&(H.animating?(d(),n.from.set(s.pos),be(e,l,n.base,n.to),n.applied=l,H.t=pt,n.rebuilt=!1,n.skip.clear()):u||(d(),n.from.set(s.pos),be(e,l,n.base,n.to),n.applied=l,n.skip.clear(),n.rebuilt=!1,H.animating=!0,H.t=0,H.version+=1));if(!H.animating){H.applied=n.applied;return}if(H.t+=a,B.id){let e=t.get(B.id);e!==void 0&&n.skip.add(e)}let f=H.t-pt;if(f>0){let e=Ja(Math.min(1,f/mt));for(let t=0;t<c;t+=1){if(n.skip.has(t))continue;let r=t*3;s.pos[r]=n.from[r]+(n.to[r]-n.from[r])*e,s.pos[r+1]=n.from[r+1]+(n.to[r+1]-n.from[r+1])*e,s.pos[r+2]=n.from[r+2]+(n.to[r+2]-n.from[r+2])*e}}!n.rebuilt&&f>=.6&&(n.rebuilt=!0,Ya(e),n.lastVersion=B.version),H.t>=1.05&&(H.animating=!1,H.t=0),H.applied=n.applied}),null}var Za=new o,Qa=new o,$a=new o,eo=new o,to=Math.PI*2;function no({model:e}){let t=(0,R.useMemo)(()=>new Map(e.nodes.map((e,t)=>[e.id,t])),[e]);return C(n=>{let r=Me.target;if(!r){Me.visible=!1;return}let{camera:i,size:a}=n,o=$e(e),s=e=>(e.project(i),{x:(e.x+1)/2*a.width,y:(1-e.y)/2*a.height,front:e.z<1}),c=(e,t,n,r)=>{Me.x=e,Me.y=t,Me.r=n,Me.visible=r};if(r.kind===`disc`){let t=s(Za.set(0,0,0)),n=e.extent.maxR,r=0;for(let e=0;e<8;e+=1){let i=e/8*to,a=s(Qa.set(Math.cos(i)*n,0,Math.sin(i)*n));r=Math.max(r,Math.hypot(a.x-t.x,a.y-t.y))}c(t.x,t.y,r*1.02+12,t.front);return}if(r.kind===`node`){let n=t.get(r.id);if(n===void 0){Me.visible=!1;return}Za.fromArray(o.pos,n*3),eo.setFromMatrixColumn(i.matrixWorld,0).normalize(),Qa.copy(Za).addScaledVector(eo,e.nodes[n].size*3);let a=s(Za),l=s(Qa);c(a.x,a.y,Math.max(44,Math.hypot(l.x-a.x,l.y-a.y)*3.2),a.front);return}let l=e.edgeById.get(r.id),u=l?t.get(l.source):void 0,d=l?t.get(l.target):void 0;if(u===void 0||d===void 0){Me.visible=!1;return}_r(o.pos,o.pos,$a,u*3,d*3,ur[e.kind]),vr(o.pos,o.pos,$a,.5,Za,u*3,d*3);let f=s(Za),p=s(Qa.fromArray(o.pos,u*3)),m=p.x,h=p.y,g=s(Qa.fromArray(o.pos,d*3)),_=Math.hypot(g.x-m,g.y-h);c(f.x,f.y,Math.min(150,Math.max(56,_*.28)),f.front)}),null}var ro=`
  varying vec2 vUv;
  void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
`,io=`
  varying vec2 vUv;
  uniform float uTime;
  uniform float uIntensity;
  float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
  float noise(vec2 p){
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1,0)), u.x), mix(hash(i + vec2(0,1)), hash(i + vec2(1,1)), u.x), u.y);
  }
  float fbm(vec2 p){ float v = 0.0, a = 0.5; for (int i = 0; i < 5; i++){ v += a * noise(p); p *= 2.06; a *= 0.5; } return v; }
  void main(){
    vec2 p = vec2(vUv.x * 4.0, vUv.y * 2.4 - uTime * 0.9);
    float n  = fbm(p * 3.0);
    float n2 = fbm(p * 7.5 + n * 1.6);
    float streak = pow(max(n2, 0.0), 1.5);
    vec3 cold = vec3(0.30, 0.45, 1.00);
    vec3 warm = vec3(0.78, 0.60, 1.00);
    vec3 col = mix(cold, warm, smoothstep(0.32, 0.86, n));
    col += vec3(1.0, 0.97, 0.95) * pow(streak, 3.5) * 0.9;
    float fade = smoothstep(0.0, 0.18, vUv.y) * smoothstep(1.0, 0.70, vUv.y);
    float a = streak * fade * uIntensity * 0.6;
    gl_FragColor = vec4(col * streak * 1.15, a);
  }
`;function ao({intensityRef:e}){let t=(0,R.useRef)(null),n=(0,R.useMemo)(()=>({uTime:{value:0},uIntensity:{value:0}}),[]);return C(n=>{t.current&&(t.current.uniforms.uTime.value=n.clock.elapsedTime,t.current.uniforms.uIntensity.value=e.current)}),(0,q.jsxs)(`mesh`,{rotation:[Math.PI/2,0,0],position:[0,0,-80],frustumCulled:!1,raycast:()=>null,children:[(0,q.jsx)(`cylinderGeometry`,{args:[40,40,220,64,1,!0]}),(0,q.jsx)(`shaderMaterial`,{ref:t,vertexShader:ro,fragmentShader:io,uniforms:n,side:1,transparent:!0,depthWrite:!1,depthTest:!1,blending:2,toneMapped:!1})]})}var oo=520;function so({intensityRef:e}){let t=(0,R.useRef)(null),n=(0,R.useRef)(null),{positions:r,colors:i,state:a}=(0,R.useMemo)(()=>{let e=new Float32Array(oo*6),t=new Float32Array(oo*6),n=new Float32Array(oo*3),r=new w,i=re(9137);for(let e=0;e<oo;e+=1){let a=i()*Math.PI*2,o=2.5+i()**.6*34;n[e*3]=Math.cos(a)*o,n[e*3+1]=Math.sin(a)*o,n[e*3+2]=-i()*300;let s=i()<.7?.62+i()*.08:.72+i()*.06;r.setHSL(s,.75,.68);for(let n=0;n<2;n+=1)t[e*6+n*3]=r.r,t[e*6+n*3+1]=r.g,t[e*6+n*3+2]=r.b}return{positions:e,colors:t,state:n}},[]);return C((i,o)=>{let s=e.current;if(n.current&&(n.current.opacity=s*.55),s<.01||!t.current)return;let c=Math.min(o,.05)*(45+260*s),l=2+16*s;for(let e=0;e<oo;e+=1){let t=a[e*3+2]+c;t>12&&(t=-300-Math.random()*60),a[e*3+2]=t;let n=a[e*3],i=a[e*3+1];r[e*6]=n,r[e*6+1]=i,r[e*6+2]=t,r[e*6+3]=n,r[e*6+4]=i,r[e*6+5]=t-l}t.current.attributes.position.needsUpdate=!0}),(0,q.jsxs)(`lineSegments`,{frustumCulled:!1,raycast:()=>null,children:[(0,q.jsxs)(`bufferGeometry`,{ref:t,children:[(0,q.jsx)(`bufferAttribute`,{attach:`attributes-position`,args:[r,3]}),(0,q.jsx)(`bufferAttribute`,{attach:`attributes-color`,args:[i,3]})]}),(0,q.jsx)(`lineBasicMaterial`,{ref:n,vertexColors:!0,transparent:!0,opacity:0,depthWrite:!1,depthTest:!1,blending:2,toneMapped:!1})]})}function co({intensityRef:e}){let t=(0,R.useRef)(null);return C(n=>{t.current&&(t.current.position.copy(n.camera.position),t.current.quaternion.copy(n.camera.quaternion),t.current.visible=e.current>.004)}),(0,q.jsxs)(`group`,{ref:t,renderOrder:50,children:[(0,q.jsx)(ao,{intensityRef:e}),(0,q.jsx)(so,{intensityRef:e})]})}var lo=[1,1,.74,.56],uo={galaxy:1,system:.55},fo={galaxy:!1,system:!0};function po(e,t,n){if(!n)return t;let r=e.edges.filter(e=>t.has(e.id));if(!r.length)return t;let i=r.map(e=>e.score).sort((e,t)=>t-e),a=i[Math.max(0,Math.ceil(i.length*uo[e.kind])-1)],o=new Set,s=new Map;return r.forEach(e=>{e.score>=a&&o.add(e.id);for(let t of[e.source,e.target]){let n=s.get(t);(!n||e.score>n.score)&&s.set(t,{id:e.id,score:e.score})}}),fo[e.kind]&&s.forEach(e=>o.add(e.id)),o}function mo(e,t){let n=new Map,r=new Map,i=new Set,a=new Set,o=new Set;e.edges.forEach(e=>{e.score>=t.minScore&&t.activeTypes.has(String(e.type))&&o.add(e.id)});let s=po(e,o,t.budget??!1),c=t=>{let n=e.nodeById.get(t);return n?lo[Math.min(n.depth,3)]:1},l=t.path;if(l&&l.nodes.length>=2){let c=new Set(l.nodes),u=new Set(l.edges),d=t.hoveredId?e.neighbors.get(t.hoveredId)??new Set:new Set;return e.nodes.forEach(e=>n.set(e.id,c.has(e.id)?1:d.has(e.id)?.45:t.isolate?0:.12)),e.edges.forEach(e=>r.set(e.id,u.has(e.id)?+!!o.has(e.id):t.isolate?0:s.has(e.id)?.05:0)),c.forEach(e=>i.add(e)),a.add(l.nodes[0]),a.add(l.nodes[l.nodes.length-1]),{node:n,edge:r,pinned:i,badges:a}}if(t.hoveredId&&e.nodeById.has(t.hoveredId)){let c=t.hoveredId,l=e.neighbors.get(c)??new Set;return e.nodes.forEach(e=>n.set(e.id,e.id===c?1:l.has(e.id)?.95:t.isolate?0:.16)),e.edges.forEach(e=>r.set(e.id,o.has(e.id)?e.source===c||e.target===c?1:t.isolate?0:s.has(e.id)?.08:0:0)),i.add(c),l.forEach(e=>i.add(e)),a.add(c),{node:n,edge:r,pinned:i,badges:a}}let u=t.selectedEdgeId??t.hoveredEdgeId;if(u){let c=e.edgeById.get(u);if(c){let l=t.selectedEdgeId?.14:.35;return e.nodes.forEach(e=>n.set(e.id,e.id===c.source||e.id===c.target?1:t.isolate?0:l)),e.edges.forEach(e=>r.set(e.id,o.has(e.id)?e.id===c.id?1:t.isolate?0:s.has(e.id)?l*.6:0:0)),i.add(c.source),i.add(c.target),a.add(c.source),a.add(c.target),{node:n,edge:r,pinned:i,badges:a}}}if(t.roleFilter&&e.centerId&&e.nodeById.has(e.centerId)){let c=e.centerId,l=new Set,u=new Set([c]);return e.incident.get(c)?.forEach(n=>{let r=e.edgeById.get(n);r&&o.has(r.id)&&oe(r,c)===t.roleFilter&&(l.add(r.id),u.add(r.source===c?r.target:r.source))}),e.nodes.forEach(e=>n.set(e.id,u.has(e.id)?1:t.isolate?0:.2)),e.edges.forEach(e=>r.set(e.id,l.has(e.id)?1:t.isolate?0:s.has(e.id)?.05:0)),u.forEach(e=>i.add(e)),a.add(c),{node:n,edge:r,pinned:i,badges:a}}return e.nodes.forEach(e=>n.set(e.id,c(e.id))),e.edges.forEach(e=>r.set(e.id,s.has(e.id)?Math.min(c(e.source),c(e.target)):0)),e.centerId&&(i.add(e.centerId),a.add(e.centerId)),t.isolate&&e.nodes.forEach(e=>{i.add(e.id),a.add(e.id)}),{node:n,edge:r,pinned:i,badges:a}}var ho={galaxy:{pos:[0,90,230],tgt:[0,0,0]},system:{pos:[0,40,118],tgt:[0,-2,0]}},go={galaxy:{orbit:.5,top:.965,front:.08},system:{orbit:.34,top:.965,front:.1}};function _o(e,t,n){return t===`top`?e===`galaxy`?1.02:1.1:t===`front`?n>=1?1.1/n:1.1:e===`galaxy`?.66:1.12}var vo=1.18;function yo(e,t,n){let r=Math.max(0,t-n);return Math.min(r,Math.max(-r,e))}function bo(e,t,n=1.6,r=`orbit`,i=0){if(!e||!e.nodes.length)return ho[t];let a=10,o=L.getState(),s=t===`galaxy`&&o.altitudeOn,c=null,l=t===`galaxy`&&xe(o.spread)===`sorted`;if(l){let{halfW:t,halfH:r}=_e(e),i=Math.max(.2,n);a=(i>=1?Math.max(r,t/i):Math.max(t,r*i))*vo;let s=i>=1?a*i:a,l=i>=1?a:a/i,[u,,d]=ve(e,o.selectedId);c=[yo(u,t,s),0,yo(d,r,l)]}else e.nodes.forEach(e=>{let t=Math.hypot(e.pos[0],e.pos[2])+e.size*3,n=(Math.abs(s?qe(e,o.altitudeWindow):e.pos[1])+e.size*3)*2;a=Math.max(a,s?Math.hypot(t,n):t)}),t===`galaxy`&&(a*=Oe(o.spread)),t===`system`&&(a=Math.max(a,Ie[1])),i&&(a*=1+i*.6);let u=Math.tan(52*Math.PI/360)*Math.min(1,n),d=a/u*_o(t,r,n),f=go[t][r],p=i&&!l?a*i*.5:0,m=c??[p,t===`galaxy`?0:-2,0];return{pos:[m[0],m[1]+d*f,m[2]+d*Math.sqrt(1-f*f)],tgt:m}}var xo=.6,So=1.7,Co=600,wo=2.4,To=2500,Eo=.05,Do=3,Oo=[0,0,0],ko=new o,Ao=new o,jo=e=>1-(1-e)**3,Mo=e=>e*e,No=(e,n,r)=>{let i=t.clamp((r-e)/(n-e),0,1);return i*i*(3-2*i)};function Po({warpRef:e,galaxy:n,system:r,next:i,panelBias:a=0}){let s=(e,t,n,r)=>bo(e,t,n,r,a),c=j(e=>e.camera),l=j(e=>e.controls),u=(0,R.useRef)({lastPhase:``,anim:null,warpDir:new o,warpAim:new o,speed:0,presetNonce:L.getState().cameraPresetNonce,spreadAbove:!1,spreadSorted:!1,spreadFocus:``,presetBeforeSpread:null,intro:null}).current,d=(e,t)=>{let n=l?l.target:new o;u.anim={t:0,dur:t,fromPos:c.position.clone(),fromTgt:n.clone(),toPos:new o().fromArray(e.pos),toTgt:new o().fromArray(e.tgt)}};(0,R.useEffect)(()=>()=>{V.plan=null,V.fade=1,V.reveal=1,Ct.anim=!1},[]);let f=(0,R.useRef)(null),p=(0,R.useRef)(!1);return(0,R.useLayoutEffect)(()=>{if(p.current||!n)return;p.current=!0,f.current=n;let e=s(n,`galaxy`,c.aspect,L.getState().cameraPreset);c.position.set(...e.pos).multiplyScalar(1.7),l&&(l.target.fromArray(e.tgt),l.update()),u.lastPhase=`galaxy`,u.intro={pose:e,frames:0,startedAt:performance.now()}},[n,c]),C((a,o)=>{let m=Math.min(o,.05),h=L.getState(),g=performance.now(),_=0;if(h.phase===`warp`){let e=(g-h.warpStartedAt)/1e3;if(_=No(0,.22,e)*(1-No(.7,1.15,e))*.85,e<xo){if(u.speed===0){let e=h.warpTarget?(h.focusId===null?n:r)?.nodeById.get(h.warpTarget)?.pos:null;e?u.warpAim.fromArray(e):u.warpAim.set(0,0,0),u.warpDir.copy(u.warpAim).sub(c.position).normalize()}u.speed=t.lerp(u.speed,150,m*3.2),c.position.addScaledVector(u.warpDir,u.speed*m*Mo(e/xo)),l&&(l.target.lerp(u.warpAim,m*3),l.update()),V.fade=1-No(0,.25,e),V.reveal=0}else if(!h.warpCommitted){let e=h.focusId;h.commitWarp();let t=e?r:n,a=h.warpTarget?i:n,o=(h.warpTarget?t?.nodeById.get(h.warpTarget)?.pos:void 0)??Oo,p=(h.warpTarget||!e?void 0:n?.nodeById.get(e)?.pos)??Oo;V.plan=t&&a&&t!==a?dt(t,a,o,p,1.1):null,V.fade=1,ko.fromArray(p).sub(Ao.fromArray(o)),c.position.add(ko),l&&l.target.add(ko);let m=h.warpTarget?`system`:`galaxy`;f.current=a,d(s(a??(h.warpTarget?r:n),m,c.aspect,h.cameraPreset),1.05),u.presetNonce=h.cameraPresetNonce,u.speed=0,u.lastPhase=`warp-committed`}let a=V.plan;a&&e>=xo&&(a.t=Math.min(1,(e-xo)/1.1),ft(a,a.t,$e(a.dst))),e>=So&&(V.landedAt=g,h.completeWarp(),u.lastPhase=h.warpTarget?`system`:`galaxy`)}else{u.speed=0,V.plan=null,V.fade=1,V.reveal=V.landedAt===0?1:Math.min(1,(g-V.landedAt)/Co);let e=c.aspect;u.lastPhase!==h.phase&&u.lastPhase!==`warp-committed`&&d(h.phase===`system`?s(r,`system`,e,h.cameraPreset):s(n,`galaxy`,e,h.cameraPreset),1.4),u.lastPhase!==h.phase&&(u.lastPhase=h.phase);let t=h.phase===`system`?r:n,i=h.phase===`system`?`system`:`galaxy`,a=i===`galaxy`&&h.spread>=.5;a!==u.spreadAbove&&(u.spreadAbove=a,a?(u.presetBeforeSpread=h.cameraPreset,h.cameraPreset!==`top`&&h.setCameraPreset(`top`)):u.presetBeforeSpread&&u.presetBeforeSpread!==`top`&&h.cameraPreset===`top`&&(h.setCameraPreset(u.presetBeforeSpread),u.presetBeforeSpread=null));let o=i===`galaxy`&&xe(h.spread)===`sorted`,l=o?h.selectedId??``:``;(o!==u.spreadSorted||l!==u.spreadFocus)&&(u.spreadSorted=o,u.spreadFocus=l,t&&p.current&&d(s(t,i,e,o?`top`:h.cameraPreset),1)),h.cameraPresetNonce!==u.presetNonce&&(u.presetNonce=h.cameraPresetNonce,t&&p.current&&(f.current=t,u.intro?u.intro.pose=s(t,i,e,h.cameraPreset):d(s(t,i,e,h.cameraPreset),1.2))),t&&f.current!==t&&!u.anim&&p.current&&(f.current=t,d(s(t,i,e,h.cameraPreset),1))}if(e.current=_,u.intro){u.intro.frames+=1;let e=u.intro.frames>=Do&&o<Eo;h.phase===`warp`?(u.intro=null,Pe()):(e||g-u.intro.startedAt>To)&&(u.anim||d(u.intro.pose,wo),u.intro=null,Pe())}if(u.anim){let e=u.anim;e.t=Math.min(e.dur,e.t+m);let t=jo(e.t/e.dur);c.position.lerpVectors(e.fromPos,e.toPos,t),l&&(l.target.lerpVectors(e.fromTgt,e.toTgt,t),l.update()),e.t>=e.dur&&(u.anim=null)}if(Ct.anim=!!u.anim||h.phase===`warp`||u.intro!==null,l){let e=h.phase!==`warp`&&!u.anim&&!B.id&&!u.intro;l.enabled!==e&&(l.enabled=e)}}),null}function Fo({warpRef:e}){let t=(0,R.useRef)(null),n=(0,R.useMemo)(()=>new a(5e-4,3e-4),[]);return C(()=>{if(!t.current)return;let n=e.current;t.current.offset.set(4e-4+n*.003,3e-4+n*.002)}),(0,q.jsxs)(O,{multisampling:0,children:[(0,q.jsx)(A,{mipmapBlur:!0,intensity:.35,luminanceThreshold:.88,luminanceSmoothing:.2,radius:.5}),(0,q.jsx)(T,{ref:t,offset:n,radialModulation:!0,modulationOffset:.35}),(0,q.jsx)(b,{eskil:!1,offset:.22,darkness:.82})]})}function Io({galaxy:e,system:t,next:n=null,warpRef:r,isolateOnFocus:i=!1,panelBias:a=0}){let o=L(e=>e.focusId),s=L(e=>e.hoveredId),c=L(e=>e.hoveredEdgeId),l=L(e=>e.selectedEdgeId),u=L(e=>e.minScore),d=L(e=>e.activeTypes),f=L(e=>e.showLabels),p=L(e=>e.edgeBudget),h=L(e=>e.setHovered),g=L(e=>e.setHoveredEdge),_=L(e=>e.selectEdge),v=L(e=>e.clearSelection),y=L(e=>e.warpTo),b=L(e=>e.selectedId),x=L(e=>e.roleFilter),S=L(e=>e.selectCompany),C=o?t:e,w=(0,R.useMemo)(()=>e=>e.score>=u&&d.has(e.type),[u,d]),T=(0,R.useMemo)(()=>me(C,s,b,w)?.path??null,[C,s,b,w]),D=s??(C&&b&&C.nodeById.has(b)?b:null),O=(0,R.useMemo)(()=>C&&D&&C.nodeById.has(D)?pe(C,D,w):null,[C,D,w]),k=(0,R.useMemo)(()=>C?mo(C,{hoveredId:D,hoveredEdgeId:c,selectedEdgeId:l,minScore:u,activeTypes:d,budget:p,path:T,roleFilter:x,isolate:i}):null,[C,D,c,l,u,d,p,T,x,i]),A=(0,R.useMemo)(()=>C?Se(C):new Set,[C]),ee=j(e=>e.gl);(0,R.useEffect)(()=>(Kt(ee),()=>Kt(null)),[ee]),(0,R.useEffect)(()=>(document.body.style.cursor=s||c?`pointer`:``,()=>{document.body.style.cursor=``}),[s,c]);let M=(0,R.useMemo)(()=>C?.kind===`galaxy`?{seed:ue(C.nodes.map(e=>e.id).join(`,`)),spiral:C.clusters.length>1,radius:C.extent.maxR}:null,[C]);return(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)(Po,{warpRef:r,galaxy:e,system:t,next:n,panelBias:a}),(0,q.jsx)(Yi,{bound:C?Math.max(C.extent.maxR*1.4,C.kind===`galaxy`?Math.hypot(_e(C).halfW,_e(C).halfH):0):void 0}),(0,q.jsx)(E,{makeDefault:!0,enablePan:!1,enableDamping:!0,dampingFactor:.07,rotateSpeed:.45,zoomSpeed:.7,minDistance:22,maxDistance:900,minPolarAngle:.03,maxPolarAngle:Math.PI*.62}),(0,q.jsx)(`fog`,{attach:`fog`,args:[F.bg,520,1600]}),(0,q.jsx)(We,{radius:1700,stars:900}),(0,q.jsx)(`ambientLight`,{intensity:.55,color:`#c9d4ff`}),(0,q.jsx)(`hemisphereLight`,{args:[`#9ab3ff`,`#3a1f5c`,.6]}),(0,q.jsx)(`directionalLight`,{position:[-60,80,70],intensity:2.4,color:`#fff3e0`}),(0,q.jsx)(`group`,{onPointerMissed:e=>e.button===0&&!B.blockClick&&v(),children:C&&k&&(0,q.jsxs)(`group`,{children:[M&&(0,q.jsx)(yi,{seed:M.seed,radius:M.radius,spiral:M.spiral,warpRef:r}),C.kind===`galaxy`&&(0,q.jsx)(xt,{model:C}),C.kind===`galaxy`&&(0,q.jsx)(Xa,{model:C}),C.kind===`galaxy`&&(0,q.jsx)(no,{model:C}),(0,q.jsx)(ka,{model:C,edges:C.edges,emphasis:k,onHover:g,onSelect:_,intensity:C.kind===`galaxy`?.85:1,hoveredEdgeId:c,warpFx:!0}),(0,q.jsx)(Mr,{model:C,emphasis:k}),(0,q.jsx)(Xr,{model:C,emphasis:k,surprise:A,allEdges:i}),(0,q.jsx)(la,{model:C}),(0,q.jsx)(Wa,{model:C,hoveredId:D,roles:O}),(0,q.jsx)(cr,{model:C,emphasis:k,hoveredId:D,onHover:h,onClick:S,onDoubleClick:y,showLabels:f,roleTags:O})]},C.kind+(C.centerId??``))}),(0,q.jsx)(ki,{}),(0,q.jsx)(co,{intensityRef:r}),(0,q.jsx)(Fo,{warpRef:r}),(0,q.jsx)(m,{})]})}function Lo(e){let t=(0,R.useRef)(0);return(0,R.useEffect)(()=>()=>Le(),[]),(0,q.jsx)(g,{dpr:[1,1.75],gl:{antialias:!1,powerPreference:`high-performance`,alpha:!1},camera:{fov:52,near:.5,far:3e3,position:ho.galaxy.pos},raycaster:{params:{Line:{threshold:1},Points:{threshold:1},Mesh:{},LOD:{},Sprite:{}}},onCreated:e=>{e.gl.toneMapping=0,e.gl.setClearColor(F.bg,1)},children:(0,q.jsx)(Io,{...e,warpRef:t})})}export{Lo as default};